/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 68.92712550607287, "KoPercent": 31.072874493927124};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.13866396761133604, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Add_User_Attribute"], "isController": false}, {"data": [0.024324324324324326, 500, 1500, "Enable_User"], "isController": false}, {"data": [0.04716981132075472, 500, 1500, "Diable_User"], "isController": false}, {"data": [0.3142857142857143, 500, 1500, "Get_User_Status"], "isController": false}, {"data": [0.0, 500, 1500, "Delete_User_Attribute"], "isController": false}, {"data": [0.11151079136690648, 500, 1500, "Get_User"], "isController": false}, {"data": [0.1423611111111111, 500, 1500, "Change_User_Password"], "isController": false}, {"data": [0.3237410071942446, 500, 1500, "Check_User_Status"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 988, 307, 31.072874493927124, 6588.346153846151, 211, 35553, 5631.5, 14361.000000000002, 16585.149999999994, 22619.730000000003, 6.020498945803322, 4.918487564820909, 2.8399017822322157], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add_User_Attribute", 45, 36, 80.0, 10175.022222222222, 1614, 35553, 10616.0, 17628.399999999998, 21242.89999999998, 35553.0, 0.4576659038901602, 0.2970557621408594, 0.8138765732265446], "isController": false}, {"data": ["Enable_User", 185, 167, 90.27027027027027, 11757.140540540537, 724, 23185, 12864.0, 18230.4, 20183.899999999998, 23179.84, 1.1273201467344278, 0.7121266608929595, 0.40402977915188965], "isController": false}, {"data": ["Diable_User", 159, 92, 57.861635220125784, 6572.188679245282, 650, 18734, 6968.0, 12019.0, 13091.0, 18039.800000000007, 1.0206374169528516, 1.0781460626825432, 0.3677882879449241], "isController": false}, {"data": ["Get_User_Status", 140, 0, 0.0, 2636.985714285714, 211, 8807, 1905.0, 5832.1, 7201.45, 8695.480000000001, 0.9018410440742602, 0.6100448887353612, 0.3073657464667156], "isController": false}, {"data": ["Delete_User_Attribute", 37, 12, 32.432432432432435, 10272.18918918919, 1554, 27377, 8262.0, 23628.2, 25137.800000000003, 27377.0, 0.3968849891661125, 0.3086731940392165, 0.7057886379604402], "isController": false}, {"data": ["Get_User", 139, 0, 0.0, 6737.805755395685, 743, 16489, 6953.0, 12933.0, 14896.0, 16112.999999999995, 0.8933506433410029, 1.1442916942491357, 0.30534445817319433], "isController": false}, {"data": ["Change_User_Password", 144, 0, 0.0, 5445.854166666668, 471, 17618, 5693.0, 10614.0, 12644.5, 16179.350000000037, 0.9255747883711812, 0.6262769838795724, 0.3516099537855366], "isController": false}, {"data": ["Check_User_Status", 139, 0, 0.0, 2599.669064748202, 222, 8889, 1907.0, 5741.0, 6672.0, 8873.0, 0.8956935825810152, 0.6067717394981538, 0.30089706289830975], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 307, 100.0, 31.072874493927124], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 988, 307, "500/Internal Server Error", 307, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Add_User_Attribute", 45, 36, "500/Internal Server Error", 36, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Enable_User", 185, 167, "500/Internal Server Error", 167, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Diable_User", 159, 92, "500/Internal Server Error", 92, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete_User_Attribute", 37, 12, "500/Internal Server Error", 12, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
