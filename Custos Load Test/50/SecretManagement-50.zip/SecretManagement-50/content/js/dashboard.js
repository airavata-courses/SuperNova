/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.91818796484111, "KoPercent": 1.0818120351588911};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.42917511832319133, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.38320209973753283, 500, 1500, "Get_SSH_Credentials"], "isController": false}, {"data": [0.3203753351206434, 500, 1500, "Save_Password_Credentials"], "isController": false}, {"data": [0.36023054755043227, 500, 1500, "Update_KV_Credentials"], "isController": false}, {"data": [0.8427109974424553, 500, 1500, "Get_JWKS"], "isController": false}, {"data": [0.4087193460490463, 500, 1500, "Get_Password_Credentials"], "isController": false}, {"data": [0.4175977653631285, 500, 1500, "Get_All_Resource_credential_Summaries"], "isController": false}, {"data": [0.4373219373219373, 500, 1500, "Get_KV_Credentials"], "isController": false}, {"data": [0.24743589743589745, 500, 1500, "Generate_SSH_Credentials"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2958, 32, 1.0818120351588911, 1871.4377958079806, 100, 37812, 1147.5, 2832.4999999999995, 3728.4999999999973, 31273.019999999968, 18.469030969030968, 25.407045347230895, 8.377785544533591], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get_SSH_Credentials", 381, 1, 0.26246719160104987, 1626.422572178476, 166, 30462, 1270.0, 3009.8, 3762.3999999999996, 5835.68, 2.4238183090527388, 8.098802603537122, 1.0083462887270183], "isController": false}, {"data": ["Save_Password_Credentials", 373, 2, 0.5361930294906166, 2524.080428954425, 195, 37812, 1479.0, 3070.2000000000007, 4473.600000000001, 35923.52, 2.3738910174000485, 1.6934993154379288, 1.3422684561275664], "isController": false}, {"data": ["Update_KV_Credentials", 347, 9, 2.5936599423631126, 2532.051873198846, 191, 35979, 1375.0, 3299.799999999999, 4819.999999999992, 34486.83999999999, 2.229933808881177, 1.5158150283561467, 1.1933630149090675], "isController": false}, {"data": ["Get_JWKS", 391, 0, 0.0, 436.04092071611245, 100, 4169, 287.0, 882.6000000000001, 1162.5999999999988, 1968.159999999996, 2.447053522255044, 5.285871277787513, 0.8268364440432083], "isController": false}, {"data": ["Get_Password_Credentials", 367, 0, 0.0, 1432.433242506811, 146, 30153, 1199.0, 2672.1999999999994, 3107.199999999996, 4551.7199999999975, 2.338920400229431, 2.689694978411191, 0.9844479418934421], "isController": false}, {"data": ["Get_All_Resource_credential_Summaries", 358, 1, 0.27932960893854747, 1666.863128491621, 157, 31025, 1248.5, 2655.4000000000005, 3145.8, 30000.010000000006, 2.2875399361022364, 2.3893270766773163, 0.9918630191693291], "isController": false}, {"data": ["Get_KV_Credentials", 351, 12, 3.4188034188034186, 1597.789173789174, 133, 30536, 1177.0, 2517.0, 3273.999999999999, 30336.2, 2.252555784447739, 2.41007374954275, 0.8909034108411467], "isController": false}, {"data": ["Generate_SSH_Credentials", 390, 7, 1.794871794871795, 3185.092307692308, 312, 37018, 1611.0, 3626.5000000000005, 6424.449999999987, 35016.50999999999, 2.4565845915455697, 1.7514852691534861, 1.2978635390880402], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 32, 100.0, 1.0818120351588911], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2958, 32, "500/Internal Server Error", 32, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Get_SSH_Credentials", 381, 1, "500/Internal Server Error", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Save_Password_Credentials", 373, 2, "500/Internal Server Error", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Update_KV_Credentials", 347, 9, "500/Internal Server Error", 9, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get_All_Resource_credential_Summaries", 358, 1, "500/Internal Server Error", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Get_KV_Credentials", 351, 12, "500/Internal Server Error", 12, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Generate_SSH_Credentials", 390, 7, "500/Internal Server Error", 7, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
