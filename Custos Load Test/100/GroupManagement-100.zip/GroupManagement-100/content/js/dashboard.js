/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 86.87318489835431, "KoPercent": 13.126815101645692};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4394966118102614, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5298245614035088, 500, 1500, "Add_Child_Group"], "isController": false}, {"data": [0.2624398073836276, 500, 1500, "Create_Groups"], "isController": false}, {"data": [0.5773381294964028, 500, 1500, "Get_All_Users_of_Group"], "isController": false}, {"data": [0.5271186440677966, 500, 1500, "Find_Group"], "isController": false}, {"data": [0.5754884547069272, 500, 1500, "Get_All_Child_Groups"], "isController": false}, {"data": [0.0, 500, 1500, "Update_Group"], "isController": false}, {"data": [0.5112068965517241, 500, 1500, "Add_User_to_group"], "isController": false}, {"data": [0.5173992673992674, 500, 1500, "Get_All_Groups_of_User"], "isController": false}, {"data": [0.5046816479400749, 500, 1500, "Change_Group_Membership"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5165, 678, 13.126815101645692, 3019.186447241051, 65, 60181, 918.0, 3456.2000000000016, 29968.199999999997, 44432.940000000104, 20.667357579298233, 20.774172949319958, 10.060765226170517], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add_Child_Group", 570, 0, 0.0, 1982.631578947366, 86, 30975, 797.5, 2635.0, 3608.8499999999935, 30439.58, 4.262957146062374, 2.903387286384713, 2.1065003085034775], "isController": false}, {"data": ["Create_Groups", 623, 66, 10.593900481540931, 8644.792937399696, 210, 60088, 1943.0, 41324.40000000001, 50024.2, 58641.439999999995, 2.492917393600845, 2.299682220557165, 1.5921562259911648], "isController": false}, {"data": ["Get_All_Users_of_Group", 556, 0, 0.0, 1015.4658273381308, 86, 7715, 723.0, 2237.8, 2832.849999999999, 3842.3299999999986, 5.4324992427721375, 12.018129805954255, 2.1379855418331757], "isController": false}, {"data": ["Find_Group", 590, 4, 0.6779661016949152, 3675.545762711865, 73, 30575, 827.0, 3862.0999999999976, 30256.149999999998, 30448.9, 3.0321095259630804, 2.573579244696378, 1.2258724060046047], "isController": false}, {"data": ["Get_All_Child_Groups", 563, 0, 0.0, 1032.4351687388987, 65, 6860, 718.0, 2403.4000000000005, 3053.799999999999, 4428.24, 5.452784503631961, 3.702633171912833, 2.1672688407990313], "isController": false}, {"data": ["Update_Group", 603, 603, 100.0, 4412.3266998341705, 166, 30753, 1235.0, 29944.0, 30443.2, 30631.56, 2.6844621726781406, 1.1361854677330319, 1.9189710062503895], "isController": false}, {"data": ["Add_User_to_group", 580, 5, 0.8620689655172413, 3120.998275862071, 90, 60181, 872.5, 3157.7, 30439.85, 31173.8, 3.5220034126998585, 2.3918869721549196, 1.6956520336533498], "isController": false}, {"data": ["Get_All_Groups_of_User", 546, 0, 0.0, 1272.9029304029305, 90, 7432, 834.0, 3115.5, 3816.9999999999986, 5722.179999999997, 5.399471919779275, 10.906594497557382, 1.9087976903907202], "isController": false}, {"data": ["Change_Group_Membership", 534, 0, 0.0, 1119.9307116104858, 158, 6542, 787.0, 2406.0, 2714.0, 4302.7, 5.343473257617451, 3.6392014184219743, 2.5047530895081804], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["504/Gateway Time-out", 8, 1.1799410029498525, 0.15488867376573087], "isController": false}, {"data": ["500/Internal Server Error", 74, 10.914454277286136, 1.4327202323330106], "isController": false}, {"data": ["404/Not Found", 596, 87.90560471976401, 11.539206195546951], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5165, 678, "404/Not Found", 596, "500/Internal Server Error", 74, "504/Gateway Time-out", 8, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Create_Groups", 623, 66, "500/Internal Server Error", 62, "504/Gateway Time-out", 4, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Find_Group", 590, 4, "500/Internal Server Error", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Update_Group", 603, 603, "404/Not Found", 596, "500/Internal Server Error", 7, null, null, null, null, null, null], "isController": false}, {"data": ["Add_User_to_group", 580, 5, "504/Gateway Time-out", 4, "500/Internal Server Error", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
