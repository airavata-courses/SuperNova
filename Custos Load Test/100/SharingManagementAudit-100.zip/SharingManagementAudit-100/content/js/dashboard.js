/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 87.56941478000854, "KoPercent": 12.430585219991457};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6018795386586928, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.4879807692307692, 500, 1500, "AUDIT_FETCH_LOGS"], "isController": false}, {"data": [0.9509803921568627, 500, 1500, "Local_Authentication_Logout"], "isController": false}, {"data": [0.0, 500, 1500, "CHECK_USER_PERMISSION_ENTITY"], "isController": false}, {"data": [0.6384364820846905, 500, 1500, "Update_Permission"], "isController": false}, {"data": [0.6813725490196079, 500, 1500, "GET_ENTITY_TYPE"], "isController": false}, {"data": [0.6152597402597403, 500, 1500, "Update_Entity"], "isController": false}, {"data": [0.6947194719471947, 500, 1500, "GET_ENTITY_TYPES"], "isController": false}, {"data": [0.7019867549668874, 500, 1500, "GET_PERMISSION_TYPES"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2341, 291, 12.430585219991457, 8206.672789406244, 73, 60126, 582.0, 60009.0, 60012.0, 60051.58, 7.927101816359425, 6.35859196695235, 4.04991562533862], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["AUDIT_FETCH_LOGS", 208, 0, 0.0, 959.0817307692312, 338, 5367, 734.0, 1763.5999999999997, 2463.1999999999994, 3625.149999999999, 0.9852776777763042, 0.6689546567988897, 0.4137396498474714], "isController": false}, {"data": ["Local_Authentication_Logout", 306, 0, 0.0, 243.98366013071882, 73, 1535, 168.0, 483.6, 728.9499999999999, 1124.5400000000004, 1.3092813500145475, 0.8845830449669684, 1.4077331702793132], "isController": false}, {"data": ["CHECK_USER_PERMISSION_ENTITY", 301, 291, 96.67774086378738, 58905.046511627916, 20811, 60126, 60011.0, 60023.6, 60071.0, 60112.0, 1.0249564989392892, 0.40301064477765935, 0.45042033644792984], "isController": false}, {"data": ["Update_Permission", 307, 0, 0.0, 848.7687296416937, 123, 6144, 580.0, 1949.1999999999998, 2669.5999999999995, 4720.680000000018, 1.3126389601505046, 0.8937250472998974, 0.6550376060907303], "isController": false}, {"data": ["GET_ENTITY_TYPE", 306, 0, 0.0, 754.2124183006537, 119, 4530, 507.5, 1704.2000000000003, 2122.7499999999995, 3799.0800000000027, 1.3084415862074865, 1.0621024365983083, 0.5098322196257685], "isController": false}, {"data": ["Update_Entity", 308, 0, 0.0, 885.2435064935065, 179, 5691, 590.0, 2059.9, 2752.4500000000007, 4245.420000000002, 1.3146605998779244, 0.8951548501052156, 0.652194906970689], "isController": false}, {"data": ["GET_ENTITY_TYPES", 303, 0, 0.0, 733.7788778877889, 117, 4515, 500.0, 1607.8000000000006, 2070.8, 4286.359999999991, 1.2952537286635804, 1.7066038236167929, 0.4730711860548623], "isController": false}, {"data": ["GET_PERMISSION_TYPES", 302, 0, 0.0, 731.4668874172183, 103, 5040, 469.5, 1649.9999999999995, 2074.7499999999995, 3841.1699999999923, 1.2912163086605555, 1.4755743801520385, 0.47664039518915036], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 16, 5.498281786941581, 0.6834686031610423], "isController": false}, {"data": ["504/Gateway Time-out", 275, 94.50171821305842, 11.747116616830414], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2341, 291, "504/Gateway Time-out", 275, "503/Service Unavailable", 16, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["CHECK_USER_PERMISSION_ENTITY", 301, 291, "504/Gateway Time-out", 275, "503/Service Unavailable", 16, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
