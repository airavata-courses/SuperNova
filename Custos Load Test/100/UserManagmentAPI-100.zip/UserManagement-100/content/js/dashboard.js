/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 62.3541887592789, "KoPercent": 37.6458112407211};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.30381760339342523, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Add_User_Attribute"], "isController": false}, {"data": [0.013888888888888888, 500, 1500, "Enable_User"], "isController": false}, {"data": [0.023952095808383235, 500, 1500, "Diable_User"], "isController": false}, {"data": [0.8658536585365854, 500, 1500, "Get_User_Status"], "isController": false}, {"data": [0.0, 500, 1500, "Delete_User_Attribute"], "isController": false}, {"data": [0.39669421487603307, 500, 1500, "Get_User"], "isController": false}, {"data": [0.11029411764705882, 500, 1500, "Change_User_Password"], "isController": false}, {"data": [0.8943089430894309, 500, 1500, "Check_User_Status"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 943, 355, 37.6458112407211, 19608.861081654304, 204, 60138, 3184.0, 60035.0, 60039.0, 60107.0, 3.5140150696468098, 33.101277981928725, 1.5472835380225374], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add_User_Attribute", 33, 19, 57.57575757575758, 13680.060606060606, 2019, 60119, 3970.0, 34449.200000000004, 42967.59999999993, 60119.0, 0.29037793127722294, 0.24877015596814642, 0.5163849734920146], "isController": false}, {"data": ["Enable_User", 216, 183, 84.72222222222223, 34408.14351851851, 1070, 60138, 35285.0, 60040.0, 60044.95, 60114.32, 0.8049069512658652, 0.5954849983603747, 0.28847739366657477], "isController": false}, {"data": ["Diable_User", 167, 134, 80.23952095808383, 37324.652694610784, 962, 60109, 34996.0, 60039.2, 60060.2, 60108.32, 0.6356770912634367, 0.45042120149631537, 0.22906723308223456], "isController": false}, {"data": ["Get_User_Status", 123, 0, 0.0, 460.19512195121945, 204, 5025, 307.0, 669.4000000000001, 832.6, 4485.720000000011, 0.524596316736755, 0.3545290148678273, 0.17879308060656982], "isController": false}, {"data": ["Delete_User_Attribute", 24, 18, 75.0, 18614.166666666668, 1792, 60010, 5396.5, 43437.0, 55960.25, 60010.0, 0.25859561033951445, 0.1834454699975218, 0.4598658265900936], "isController": false}, {"data": ["Get_User", 121, 0, 0.0, 1354.5619834710749, 679, 7568, 982.0, 1844.9999999999998, 4215.599999999989, 7283.980000000001, 0.5079956841358405, 34.851175435364894, 0.17363133735111738], "isController": false}, {"data": ["Change_User_Password", 136, 1, 0.7352941176470589, 26869.88235294118, 528, 60109, 30564.0, 58080.399999999994, 59610.3, 60035.74, 0.5142554639643047, 0.3471992456326099, 0.19535681199425245], "isController": false}, {"data": ["Check_User_Status", 123, 0, 0.0, 429.17073170731715, 208, 2339, 295.0, 570.4000000000003, 1629.3999999999999, 2305.640000000001, 0.5215245476940559, 0.3529830780124403, 0.1751996527409719], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 11, 3.0985915492957745, 1.1664899257688228], "isController": false}, {"data": ["504/Gateway Time-out", 111, 31.267605633802816, 11.770943796394485], "isController": false}, {"data": ["500/Internal Server Error", 233, 65.63380281690141, 24.708377518557793], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 943, 355, "500/Internal Server Error", 233, "504/Gateway Time-out", 111, "503/Service Unavailable", 11, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Add_User_Attribute", 33, 19, "500/Internal Server Error", 18, "504/Gateway Time-out", 1, null, null, null, null, null, null], "isController": false}, {"data": ["Enable_User", 216, 183, "500/Internal Server Error", 129, "504/Gateway Time-out", 49, "503/Service Unavailable", 5, null, null, null, null], "isController": false}, {"data": ["Diable_User", 167, 134, "500/Internal Server Error", 69, "504/Gateway Time-out", 59, "503/Service Unavailable", 6, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete_User_Attribute", 24, 18, "500/Internal Server Error", 17, "504/Gateway Time-out", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Change_User_Password", 136, 1, "504/Gateway Time-out", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
