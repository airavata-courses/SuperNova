/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 94.65151725093529, "KoPercent": 5.348482749064709};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.18013024802549535, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.6363636363636364, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.3382352941176471, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.02913533834586466, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.016917293233082706, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.018796992481203006, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.002819548872180451, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.27941176470588236, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.0625, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.03195488721804511, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.03125, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.02913533834586466, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.022321428571428572, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.8580827067669173, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.022321428571428572, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.8571428571428571, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.022321428571428572, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.017857142857142856, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.03571428571428571, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.02631578947368421, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9107142857142857, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.90625, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.026785714285714284, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.008928571428571428, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.75, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7217, 386, 5.348482749064709, 58163.21061382834, 21, 311049, 37664.0, 163554.79999999993, 214629.09999999998, 270457.13999999996, 22.63652645214713, 13267.462758540449, 19.24359042279994], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 33, 0, 0.0, 1351.6969696969697, 38, 6615, 490.0, 4952.400000000002, 6393.799999999999, 6615.0, 0.29267254376784857, 21.595460998057717, 0.13919094610834204], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 34, 0, 0.0, 6901.2058823529405, 132, 59421, 1599.0, 24592.0, 37201.5, 59421.0, 0.24225496622680764, 0.058907701748510836, 0.14099996081169663], "isController": false}, {"data": ["GET_UI_login-7", 532, 17, 3.1954887218045114, 51112.26127819551, 82, 177836, 46809.0, 104844.5, 122362.69999999987, 156580.36999999997, 1.804754102253568, 371.39060443360574, 1.0236816729256353], "isController": false}, {"data": ["GET_UI_login-6", 532, 0, 0.0, 54762.50187969924, 168, 176580, 50307.5, 109459.9, 140624.24999999997, 176249.50999999998, 1.7808365915055433, 604.5470671638169, 1.0486762350369558], "isController": false}, {"data": ["GET_UI_login-9", 532, 42, 7.894736842105263, 57391.868421052655, 43, 149197, 51721.5, 117790.5, 128994.35, 142280.31999999998, 1.7006911455369644, 120.93465985377891, 0.9147683407711931], "isController": false}, {"data": ["GET_UI_login-8", 532, 151, 28.383458646616543, 154057.30075187984, 786, 307075, 166315.5, 247433.0, 268814.69999999995, 287920.9999999998, 1.6815381649108498, 5420.672641935096, 0.7056207862771314], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 34, 0, 0.0, 3139.7352941176473, 136, 11383, 2137.5, 7054.0, 10850.5, 11383.0, 0.2775011834609295, 0.6118161432232578, 0.13604061923572908], "isController": false}, {"data": ["GET_UI_dashboard-9", 112, 0, 0.0, 41193.71428571426, 163, 131240, 36050.0, 92931.5, 109512.74999999996, 130920.85, 0.3726675007320254, 0.8425668794670189, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 532, 0, 0.0, 46946.17293233083, 60, 161818, 45183.5, 96996.79999999997, 107981.15, 132996.66, 1.8040931210471878, 2.1212188649812638, 1.0606094324906319], "isController": false}, {"data": ["GET_UI_dashboard-8", 112, 0, 0.0, 49690.53571428572, 180, 142719, 44566.5, 101119.90000000001, 113031.39999999994, 141558.23000000004, 0.3710771840542833, 59.71699877246342, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 532, 0, 0.0, 30071.612781954882, 153, 162064, 27842.5, 57626.09999999999, 80950.55, 108008.17999999998, 1.9564793668656244, 2.1246143124556394, 1.1387321314960082], "isController": false}, {"data": ["GET_UI_dashboard-7", 112, 0, 0.0, 46520.705357142855, 237, 128611, 42963.5, 94248.4, 102120.55, 128422.63, 0.37229091876080306, 0.07525802752293578, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 532, 0, 0.0, 423.52067669172885, 74, 2828, 196.5, 1298.1999999999998, 1462.05, 2432.7699999999986, 1.94917489814462, 2.7810005138567284, 1.1858749624454086], "isController": false}, {"data": ["GET_UI_dashboard-6", 112, 0, 0.0, 43770.92857142859, 125, 144195, 41801.0, 87416.2, 96955.39999999995, 140634.95000000013, 0.37175708330014073, 0.0751501135186808, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 532, 0, 0.0, 429.82518796992485, 72, 2828, 199.0, 1308.8, 1487.05, 2423.0299999999997, 1.9491391912537874, 14.220721579938523, 1.227729275740911], "isController": false}, {"data": ["GET_UI_dashboard-5", 112, 0, 0.0, 45588.482142857145, 317, 141001, 43495.5, 92112.6, 103764.4, 139425.92000000004, 0.37173363957104594, 0.07478235327308151, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 532, 0, 0.0, 46696.699248120305, 47, 133645, 45412.5, 95736.2, 106308.79999999999, 132114.69, 1.6851334486319378, 12.018095288436564, 0.9890285181912056], "isController": false}, {"data": ["GET_UI_dashboard-4", 112, 0, 0.0, 44971.96428571428, 231, 141006, 38241.5, 93884.5, 112663.94999999992, 140126.68000000002, 0.3717768276814403, 0.07515410481450993, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 532, 0, 0.0, 48031.184210526335, 62, 163254, 45169.5, 95675.9, 106483.09999999996, 134859.53999999986, 1.6888888888888889, 132.3765625, 0.9912326388888889], "isController": false}, {"data": ["GET_UI_dashboard-3", 112, 0, 0.0, 304.07142857142867, 77, 3504, 178.0, 607.2, 982.7999999999998, 3248.420000000009, 0.40656456572007305, 0.5753047419222518, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 112, 0, 0.0, 307.2321428571427, 72, 3506, 179.5, 605.4, 990.8499999999997, 3254.450000000009, 0.40656456572007305, 2.961092315566704, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 112, 0, 0.0, 45751.49999999999, 234, 136031, 39458.5, 99736.20000000003, 119811.44999999997, 135756.05000000002, 0.37178299823071126, 0.07442921351298419, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 112, 0, 0.0, 52282.535714285725, 450, 142663, 45471.5, 108186.40000000001, 123462.65, 141575.16000000003, 0.4002458653172663, 0.4346419943679689, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 32, 0, 0.0, 693.46875, 21, 3624, 199.5, 2294.7, 3331.499999999999, 3624.0, 0.3572425341892269, 0.17408596148478928, 0.25641920178621264], "isController": false}, {"data": ["GET_UI_dashboard", 112, 0, 0.0, 129457.00892857143, 13045, 223350, 134073.5, 191167.30000000002, 195997.29999999996, 221579.01000000007, 0.36517293546872553, 63.53340107135055, 0.0], "isController": false}, {"data": ["GET_UI_login", 532, 176, 33.08270676691729, 193110.4548872182, 10650, 311049, 206350.0, 269932.6, 280070.2, 304580.2699999999, 1.6686479246975576, 6568.638908323557, 9.50398597488873], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 61, 15.803108808290155, 0.8452265484273244], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 149, 38.601036269430054, 2.0645697658306776], "isController": false}, {"data": ["Assertion failed", 176, 45.59585492227979, 2.4386864348067063], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7217, 386, "Assertion failed", 176, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 149, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 61, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 532, 17, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 15, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 532, 42, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 40, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 532, 151, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 145, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 6, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 532, 176, "Assertion failed", 176, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
