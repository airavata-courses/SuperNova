/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 97.97734627831716, "KoPercent": 2.0226537216828477};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.2978964401294498, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8183206106870229, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.772795216741405, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.09134199134199134, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.06926406926406926, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.10865800865800866, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.004329004329004329, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.1536144578313253, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.14084507042253522, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.13073593073593073, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.12147887323943662, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.15627705627705626, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.13497652582159625, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.925974025974026, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.13908450704225353, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9277056277056277, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.15140845070422534, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.1303030303030303, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.142018779342723, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.11038961038961038, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9096244131455399, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9066901408450704, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.15316901408450703, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.14553990610328638, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9221374045801527, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.034624413145539906, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 24720, 500, 2.0226537216828477, 12077.720752427149, 5, 171710, 7083.0, 33797.9, 56697.25000000007, 114422.26000000013, 96.44533398878706, 44310.0910269592, 58.00602405378623], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 655, 0, 0.0, 506.3725190839695, 12, 5499, 257.0, 1022.8, 2018.1999999999982, 4360.719999999999, 2.692902249703986, 198.7014728350916, 1.2807064410213294], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 669, 0, 0.0, 560.6442451420032, 13, 5045, 298.0, 1309.0, 2076.5, 3285.2999999999993, 2.7376855303703036, 0.6657067354123102, 1.5934185313483409], "isController": false}, {"data": ["GET_UI_login-7", 1155, 41, 3.54978354978355, 10897.502164502148, 28, 99550, 6627.0, 27021.200000000015, 34809.600000000006, 53346.96000000002, 4.588121730218442, 940.7442053549439, 2.5929218787861936], "isController": false}, {"data": ["GET_UI_login-6", 1155, 0, 0.0, 10749.38874458876, 64, 97956, 6794.0, 26278.400000000016, 32525.000000000004, 44774.84000000007, 4.5889967380378165, 1557.84339362641, 2.7023096025750033], "isController": false}, {"data": ["GET_UI_login-9", 1155, 38, 3.29004329004329, 11244.88311688311, 34, 93557, 6633.0, 28661.000000000004, 34150.00000000001, 55395.520000000135, 4.594637600445541, 342.6819308976947, 2.594918238821704], "isController": false}, {"data": ["GET_UI_login-8", 1155, 194, 16.796536796536795, 42519.10909090912, 110, 164226, 27875.0, 103018.20000000004, 120832.60000000002, 138035.84000000005, 4.509604872715915, 16887.998560855263, 2.198523885288146], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 664, 0, 0.0, 2896.5481927710844, 277, 10006, 2348.5, 5759.5, 7115.0, 9102.75, 2.7165352720012765, 1296.4622954799759, 1.3317389712350007], "isController": false}, {"data": ["GET_UI_dashboard-9", 852, 0, 0.0, 10935.227699530535, 14, 40126, 9089.0, 27203.00000000002, 31040.749999999975, 35525.73000000001, 3.4567119852968022, 1.634276315589284, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1155, 0, 0.0, 9705.283116883102, 11, 104996, 6098.0, 25445.600000000002, 31152.2, 38722.280000000006, 4.592463588324407, 5.399732578459557, 2.6998662892297784], "isController": false}, {"data": ["GET_UI_dashboard-8", 852, 0, 0.0, 12771.473004694826, 84, 68379, 9780.0, 30662.900000000005, 34912.599999999984, 57352.57000000001, 3.38468628089718, 1323.6690519452013, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1155, 0, 0.0, 8313.448484848497, 5, 56021, 5158.0, 18871.800000000003, 24294.800000000003, 34816.920000000006, 4.5943086261624995, 4.989132023723339, 2.6740311925711424], "isController": false}, {"data": ["GET_UI_dashboard-7", 852, 0, 0.0, 11260.237089201884, 14, 37515, 8951.0, 27936.0, 31418.5, 36197.82000000003, 3.4526496654739085, 4.9999879694205465, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1155, 0, 0.0, 260.94199134199107, 63, 4883, 100.0, 523.0000000000005, 1385.4000000000005, 2309.3600000000065, 4.5955333802833715, 6.556713152923834, 2.7959153280434967], "isController": false}, {"data": ["GET_UI_dashboard-6", 852, 0, 0.0, 11034.365023474174, 13, 38783, 9297.5, 26323.000000000004, 30705.29999999999, 37855.85, 3.453223413827485, 0.6980637174436419, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1155, 0, 0.0, 256.8995670995668, 64, 4964, 103.0, 504.4000000000001, 1327.800000000001, 2196.0800000000017, 4.59536882310814, 33.527344216250896, 2.89454383877417], "isController": false}, {"data": ["GET_UI_dashboard-5", 852, 0, 0.0, 11131.440140845065, 19, 38796, 8990.0, 27809.600000000002, 30777.449999999997, 37934.9, 3.4657674112100487, 0.6972149284270216, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1155, 0, 0.0, 9576.977489177487, 14, 95138, 5605.0, 24769.000000000004, 30761.0, 38951.160000000076, 4.594034516910422, 32.7639004658172, 2.6963034615851207], "isController": false}, {"data": ["GET_UI_dashboard-4", 852, 0, 0.0, 11181.139671361501, 32, 38383, 9057.5, 27165.700000000004, 30870.4, 35140.66, 3.4487923155078266, 0.6971679778419141, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1155, 0, 0.0, 10076.98528138527, 19, 104512, 6324.0, 26026.000000000004, 31108.200000000004, 40907.80000000001, 4.590328119038534, 359.79386278346766, 2.69412812455289], "isController": false}, {"data": ["GET_UI_dashboard-3", 852, 0, 0.0, 304.6960093896714, 63, 3343, 111.0, 714.4000000000001, 1448.5999999999985, 3001.76, 3.466260913432982, 4.9048945933246, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 852, 0, 0.0, 311.57159624413123, 64, 3390, 112.5, 711.4000000000001, 1442.3499999999963, 3062.170000000003, 3.4663173226360287, 25.245893156464355, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 852, 0, 0.0, 11245.734741784034, 33, 38192, 9192.5, 27053.4, 31167.499999999996, 37859.47, 3.45417541697411, 0.6915097270309498, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 852, 0, 0.0, 11012.26525821597, 27, 38059, 8043.0, 27421.40000000001, 30580.39999999999, 35691.33, 3.449169284580756, 3.7455822699744146, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 655, 0, 0.0, 212.19083969465655, 6, 4683, 68.0, 600.7999999999998, 779.7999999999997, 2039.1999999999953, 2.6937106995834, 1.3907759429015583, 1.933473988470507], "isController": false}, {"data": ["GET_UI_dashboard", 852, 0, 0.0, 30797.52816901408, 238, 86970, 27607.0, 64780.3, 70419.14999999998, 78544.77000000003, 3.3650086494940634, 1358.0725116844692, 0.0], "isController": false}, {"data": ["GET_UI_login", 1155, 227, 19.653679653679653, 52511.49956709962, 1723, 171710, 39493.0, 115969.20000000006, 132405.60000000003, 150287.92000000004, 4.506244367194541, 20100.049788452798, 26.083619332324794], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 96, 19.2, 0.3883495145631068], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 169, 33.8, 0.6836569579288025], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 8, 1.6, 0.032362459546925564], "isController": false}, {"data": ["Assertion failed", 227, 45.4, 0.9182847896440129], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 24720, 500, "Assertion failed", 227, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 169, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 96, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 8, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 1155, 41, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 34, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 3, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 1155, 38, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 34, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 1155, 194, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 164, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 28, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 2, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 1155, 227, "Assertion failed", 227, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
