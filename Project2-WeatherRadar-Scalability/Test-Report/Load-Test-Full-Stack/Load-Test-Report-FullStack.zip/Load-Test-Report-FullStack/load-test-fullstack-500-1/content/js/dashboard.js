/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.60894784897148, "KoPercent": 1.3910521510285192};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.31005961652075836, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9318980667838312, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.8570190641247833, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.040098704503392965, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.041949413942011106, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.0459592843923504, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.7613043478260869, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.08302446256486286, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.09531153608883405, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.08005930318754632, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.12214682294879704, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.083765752409192, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9518815545959285, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.10044477390659748, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9509561998766194, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.09970348406226835, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.0931523750771129, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.10081541882876205, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.0891425046267736, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9488510007412898, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9492216456634545, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.10044477390659748, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.10452186805040771, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9613676731793961, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.016679021497405487, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 37238, 518, 1.3910521510285192, 7468.764380471527, 4, 102416, 8739.0, 26093.500000000007, 37951.200000000026, 64137.47000000009, 147.26202104647072, 65407.81341373275, 84.93461071987868], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1138, 0, 0.0, 274.19947275922704, 9, 1917, 206.0, 566.4000000000005, 745.7999999999993, 1253.2699999999993, 4.670538261065851, 344.62551750938826, 2.2212423175186227], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1154, 0, 0.0, 346.1507798960142, 7, 1986, 265.0, 751.0, 957.5, 1817.3000000000106, 4.729740806924931, 1.1501029891838943, 2.752856954030526], "isController": false}, {"data": ["GET_UI_login-7", 1621, 36, 2.2208513263417644, 7021.507711289333, 182, 49640, 6059.0, 12719.4, 15817.499999999984, 24664.899999999994, 6.456958258812095, 1342.0103364920215, 3.6993508685624605], "isController": false}, {"data": ["GET_UI_login-6", 1621, 0, 0.0, 6969.922887106725, 127, 43768, 6491.0, 12591.8, 13906.699999999999, 21259.72, 6.46643715668245, 2195.1849129327247, 3.8078726616010914], "isController": false}, {"data": ["GET_UI_login-9", 1621, 47, 2.8994447871684144, 6775.919802590997, 164, 58641, 5963.0, 12710.599999999999, 14200.999999999985, 25193.91999999997, 6.459557036175114, 483.6668476173659, 3.6629051917544015], "isController": false}, {"data": ["GET_UI_login-8", 1621, 192, 11.844540407156076, 27384.28562615666, 53, 96091, 24611.0, 52116.2, 60100.89999999999, 74481.93999999996, 6.4170318555554235, 25460.66724228452, 3.314627299502393], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1150, 0, 0.0, 546.8443478260868, 20, 2531, 399.0, 1265.9, 1583.45, 1989.3500000000001, 4.701188378662328, 337.58021722045305, 2.3046841465707897], "isController": false}, {"data": ["GET_UI_dashboard-9", 1349, 0, 0.0, 6579.280207561152, 95, 16284, 6549.0, 12115.0, 13187.5, 15465.0, 5.4894971148603, 8.92890523903118, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1621, 0, 0.0, 5951.140653917339, 27, 33617, 4952.0, 11952.6, 12440.9, 14359.46, 6.471832954046392, 7.60945984049986, 3.80472992024993], "isController": false}, {"data": ["GET_UI_dashboard-8", 1349, 0, 0.0, 8586.394366197184, 112, 43861, 8261.0, 14933.0, 24536.0, 34610.5, 5.487398102800241, 2307.6934578591013, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1621, 0, 0.0, 5830.320172732885, 8, 50263, 4726.0, 12102.0, 13236.9, 15484.119999999999, 6.47077373847855, 7.026855856629051, 3.7661925274738435], "isController": false}, {"data": ["GET_UI_dashboard-7", 1349, 0, 0.0, 6886.751667902148, 84, 16273, 6947.0, 12434.0, 13209.5, 14932.5, 5.490100319475815, 22.712109780385813, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1621, 0, 0.0, 213.26218383713737, 59, 1893, 117.0, 413.5999999999999, 682.0, 1763.7199999999993, 6.47260820955119, 9.234844330228798, 3.9379247212406168], "isController": false}, {"data": ["GET_UI_dashboard-6", 1349, 0, 0.0, 6816.263899184589, 76, 16402, 7056.0, 12414.0, 13174.5, 15022.5, 5.493901321550021, 1.110583567930522, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1621, 0, 0.0, 215.78901912399743, 61, 1989, 121.0, 426.79999999999995, 701.3999999999992, 1775.2599999999995, 6.472556520072512, 47.22311500142747, 4.076952104928487], "isController": false}, {"data": ["GET_UI_dashboard-5", 1349, 0, 0.0, 6814.797627872493, 65, 16319, 7034.0, 12440.0, 13185.0, 15040.5, 5.49378945225005, 1.1051959249643657, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1621, 0, 0.0, 6074.59099321406, 49, 43792, 5132.0, 12028.8, 12635.599999999999, 18370.37999999999, 6.471936310716824, 46.15678796598141, 3.7984704323640734], "isController": false}, {"data": ["GET_UI_dashboard-4", 1349, 0, 0.0, 6805.595997034845, 62, 16412, 7034.0, 12399.0, 13144.0, 15029.5, 5.493901321550021, 1.110583567930522, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1621, 0, 0.0, 6140.7803824799485, 48, 40343, 5221.0, 12073.8, 12650.899999999992, 15588.559999999998, 6.470386307209631, 507.15443924732364, 3.797560713508777], "isController": false}, {"data": ["GET_UI_dashboard-3", 1349, 0, 0.0, 214.72942920681982, 62, 1968, 114.0, 456.0, 677.0, 1674.5, 5.4936775875058546, 7.773768383101546, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 1349, 0, 0.0, 214.9873980726463, 63, 1997, 117.0, 454.0, 671.5, 1455.5, 5.493699960090245, 40.01173271714165, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 1349, 0, 0.0, 6803.555226093401, 65, 16403, 7002.0, 12425.0, 13165.0, 15061.0, 5.494102697771407, 1.0998936064874396, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 1349, 0, 0.0, 6570.0659747961445, 64, 15201, 6574.0, 12491.0, 13288.5, 14278.0, 5.465100733676607, 5.934757827976941, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1126, 0, 0.0, 174.6207815275311, 4, 1977, 85.0, 420.0, 612.6499999999999, 1104.8200000000006, 4.633096603767374, 3.545796157893546, 3.325513675555684], "isController": false}, {"data": ["GET_UI_dashboard", 1349, 0, 0.0, 20932.834692364722, 269, 56837, 20946.0, 35484.0, 37099.5, 44131.5, 5.45405293948791, 2382.862149563706, 0.0], "isController": false}, {"data": ["GET_UI_login", 1621, 243, 14.99074645280691, 33781.509561998784, 3005, 102416, 31534.0, 62237.0, 70248.89999999998, 87101.85999999999, 6.410433861011038, 30041.579358716866, 37.35623345857935], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 111, 21.428571428571427, 0.29808260379182555], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 162, 31.274131274131275, 0.4350394758042859], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 2, 0.3861003861003861, 0.005370857725978838], "isController": false}, {"data": ["Assertion failed", 243, 46.91119691119691, 0.6525592137064289], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 37238, 518, "Assertion failed", 243, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 162, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 111, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 2, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 1621, 36, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 34, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 1621, 47, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 46, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 1621, 192, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 160, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 31, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 1621, 243, "Assertion failed", 243, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
