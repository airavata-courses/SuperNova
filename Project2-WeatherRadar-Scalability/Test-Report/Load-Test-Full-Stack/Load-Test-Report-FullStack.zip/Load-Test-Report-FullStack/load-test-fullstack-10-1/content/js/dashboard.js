/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.96653466451001, "KoPercent": 0.033465335489988285};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9868369680406046, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9952761627906976, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.8792480115690527, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.9989098837209303, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [1.0, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.9985475671750181, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.9992769342010123, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.9996368917937546, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.9996368917937546, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.9996368917937546, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.9996368917937546, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.9996384671005062, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9989106753812637, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9985475671750181, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.9996368917937546, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [1.0, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [1.0, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.9934640522875817, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.8011569052783803, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 35858, 12, 0.033465335489988285, 85.12516035473305, 2, 1499, 57.0, 177.0, 350.9500000000007, 709.9900000000016, 179.2675915510561, 73434.57476018622, 97.4893177415323], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1373, 0, 0.0, 26.407137654770576, 6, 133, 22.0, 45.0, 57.0, 86.51999999999998, 6.939951475940154, 512.0789586123888, 3.3005433288895065], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1376, 0, 0.0, 28.301598837209283, 5, 1054, 17.0, 35.0, 45.0, 317.6400000000067, 6.935344045482954, 1.68642643293482, 4.036586963972501], "isController": false}, {"data": ["GET_UI_login-7", 1383, 0, 0.0, 63.97107736804036, 8, 650, 50.0, 127.0, 157.79999999999995, 225.0, 6.93406868889446, 1473.6453420735147, 4.062930872399098], "isController": false}, {"data": ["GET_UI_login-6", 1383, 0, 0.0, 67.17932031814904, 11, 1031, 56.0, 128.20000000000027, 160.0, 214.16000000000008, 6.932157088794767, 2353.2845501600837, 4.082119848186762], "isController": false}, {"data": ["GET_UI_login-9", 1383, 0, 0.0, 67.94360086767895, 4, 542, 55.0, 130.0, 160.0, 224.32000000000016, 6.935181377809426, 534.4424149274388, 4.050037562431676], "isController": false}, {"data": ["GET_UI_login-8", 1383, 6, 0.43383947939262474, 366.66738973246544, 86, 1387, 337.0, 609.6000000000001, 672.8, 785.4800000000002, 6.930593836131296, 31056.021781430092, 4.043277060886996], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1376, 0, 0.0, 74.34447674418595, 7, 1129, 68.5, 119.29999999999995, 145.0, 217.23000000000002, 6.943498291879235, 505.8241653120916, 3.4039415454329847], "isController": false}, {"data": ["GET_UI_dashboard-9", 1377, 0, 0.0, 55.361655773420395, 3, 323, 43.0, 110.20000000000005, 142.0, 197.22000000000003, 6.9359445124439, 1.4020903457772338, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1383, 0, 0.0, 44.93564714389016, 2, 1020, 28.0, 102.0, 139.0, 195.32000000000016, 6.932643577905771, 8.151272331834518, 4.075636165917259], "isController": false}, {"data": ["GET_UI_dashboard-8", 1377, 0, 0.0, 59.48874364560638, 10, 683, 43.0, 119.0, 152.0999999999999, 247.66000000000008, 6.93531571551607, 137.40493924043938, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1383, 0, 0.0, 47.630513376717246, 2, 1023, 32.0, 110.60000000000014, 141.0, 201.16000000000008, 6.918216970891465, 7.512751241827449, 4.026618471339172], "isController": false}, {"data": ["GET_UI_dashboard-7", 1377, 0, 0.0, 44.4255628177197, 3, 639, 28.0, 105.0, 138.0999999999999, 208.10000000000014, 6.935385576211174, 1.401977357691126, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1383, 0, 0.0, 82.05350686912485, 61, 586, 76.0, 93.0, 103.0, 279.96000000000254, 6.929690944802982, 9.886990693708162, 4.216013143176033], "isController": false}, {"data": ["GET_UI_dashboard-6", 1377, 0, 0.0, 40.08206245461148, 3, 1012, 25.0, 88.0, 123.29999999999973, 200.22000000000003, 6.935175998348049, 1.4019349918535606, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1383, 0, 0.0, 83.4374548083875, 59, 585, 77.0, 94.0, 104.0, 320.32000000000016, 6.929760389629911, 50.558827998950264, 4.364936964171184], "isController": false}, {"data": ["GET_UI_dashboard-5", 1377, 0, 0.0, 39.208424110384904, 3, 1012, 25.0, 86.20000000000005, 125.0, 201.44000000000005, 6.935106141875047, 1.3951483058850191, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1383, 0, 0.0, 44.904555314533624, 2, 1020, 28.0, 102.0, 134.79999999999995, 195.0, 6.932608826419105, 49.44222876888547, 4.068845610036994], "isController": false}, {"data": ["GET_UI_dashboard-4", 1377, 0, 0.0, 39.45896877269424, 2, 1012, 25.0, 87.20000000000005, 121.0, 200.44000000000005, 6.935141069935634, 1.4019279311295667, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1383, 0, 0.0, 49.74258857556037, 3, 1023, 35.0, 111.0, 142.79999999999995, 203.48000000000025, 6.932539324490962, 543.3783899045836, 4.068804818377997], "isController": false}, {"data": ["GET_UI_dashboard-3", 1377, 0, 0.0, 87.64342774146697, 60, 1067, 77.0, 95.0, 113.09999999999991, 391.32000000000016, 6.9328714775525, 9.81028395602888, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 1377, 0, 0.0, 88.81771968046479, 62, 1095, 77.0, 96.0, 115.0, 395.98000000000025, 6.932173440260976, 50.48842726315074, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 1377, 0, 0.0, 38.68046477850392, 3, 1012, 24.0, 85.0, 122.0, 195.44000000000005, 6.935106141875047, 1.3883757412933444, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 1377, 0, 0.0, 38.16267247639795, 2, 248, 23.0, 94.0, 123.0, 188.44000000000005, 6.934721956427586, 7.530674624558081, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1373, 0, 0.0, 11.869628550619066, 2, 106, 10.0, 21.600000000000136, 27.0, 46.0, 6.944901087006004, 3.4420569195468866, 4.984865526317786], "isController": false}, {"data": ["GET_UI_dashboard", 1377, 0, 0.0, 165.27668845315904, 68, 1156, 126.0, 307.4000000000001, 374.0999999999999, 536.6600000000001, 6.931580219072164, 213.5376979395286, 0.0], "isController": false}, {"data": ["GET_UI_login", 1383, 6, 0.43383947939262474, 454.92263195950835, 95, 1499, 425.0, 763.6000000000001, 839.8, 1014.5200000000038, 6.914135733033371, 35998.863291502625, 40.960832044431946], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 6, 50.0, 0.016732667744994142], "isController": false}, {"data": ["Assertion failed", 6, 50.0, 0.016732667744994142], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 35858, 12, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 6, "Assertion failed", 6, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-8", 1383, 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 6, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 1383, 6, "Assertion failed", 6, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
