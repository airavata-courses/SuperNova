/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.83528249052874, "KoPercent": 0.1647175094712568};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6928121396804481, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9889319313779745, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9950522264980759, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.5901940220241216, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.5742003146303094, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.627163083377032, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.1588883062401678, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.5283122594832326, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.6890210924824229, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.680650235972732, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.6614386154678205, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.6769795490298899, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.6792861005949161, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9965915049816466, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.7098431584640346, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9960671211326692, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.7028123309897242, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.6798636601992659, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.7030827474310438, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.6646565285789198, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9986479177934018, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9986479177934018, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.7174148188209843, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.685235262303948, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [1.0, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.2652785289345592, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0886208704771893, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 48568, 80, 0.1647175094712568, 928.970989128651, 1, 18615, 314.0, 2137.9000000000015, 3230.600000000006, 9037.820000000029, 194.19820468222076, 82695.63707978468, 106.61301830304484], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1807, 0, 0.0, 142.13558384061986, 11, 1181, 98.0, 287.0, 388.1999999999998, 820.6400000000012, 7.291200122663246, 537.9965809259663, 3.4675922458369146], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1819, 0, 0.0, 114.1302913688842, 7, 949, 81.0, 242.0, 304.0, 512.7999999999981, 7.31888868770998, 1.7796907062888527, 4.2598219315187], "isController": false}, {"data": ["GET_UI_login-7", 1907, 2, 0.1048767697954903, 924.2826428946001, 9, 4523, 709.0, 2081.6000000000004, 2655.999999999999, 3792.3600000000006, 7.641234618358998, 1622.2440274367705, 4.472590276358653], "isController": false}, {"data": ["GET_UI_login-6", 1907, 0, 0.0, 946.8405873099099, 14, 5510, 759.0, 2126.4, 2553.9999999999973, 3431.6400000000012, 7.640714148342842, 2593.8209892198115, 4.499365851026107], "isController": false}, {"data": ["GET_UI_login-9", 1907, 3, 0.15731515469323545, 857.728369166228, 4, 5048, 591.0, 1985.4000000000003, 2459.1999999999994, 3904.2000000000044, 7.6465965227433115, 588.3586107977101, 4.4584679941618015], "isController": false}, {"data": ["GET_UI_login-8", 1907, 35, 1.8353434714210803, 4112.9910854745585, 29, 17613, 3242.0, 8498.8, 9995.399999999998, 13157.800000000014, 7.635146497121306, 33731.73179549183, 4.3916105474724345], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1819, 0, 0.0, 940.6882902693796, 140, 3071, 847.0, 1633.0, 1883.0, 2347.2, 7.31647473825201, 2523.168621941581, 3.586787420510263], "isController": false}, {"data": ["GET_UI_dashboard-9", 1849, 0, 0.0, 700.5116279069765, 5, 3356, 475.0, 1671.0, 2061.0, 2707.5, 7.432418852376646, 2.429317719324691, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1907, 0, 0.0, 698.415836392238, 4, 3991, 506.0, 1652.2, 2145.2, 2949.680000000002, 7.641847026812584, 8.985140449494484, 4.492570224747242], "isController": false}, {"data": ["GET_UI_dashboard-8", 1849, 0, 0.0, 809.9691725256894, 16, 11787, 581.0, 1796.0, 2244.0, 4558.0, 7.431851250432085, 526.0770378179337, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1907, 0, 0.0, 715.0886208704776, 3, 3482, 524.0, 1700.4, 2146.399999999999, 2955.4400000000023, 7.636308303434136, 8.292553548260507, 4.444570067233149], "isController": false}, {"data": ["GET_UI_dashboard-7", 1849, 0, 0.0, 703.8999459167113, 5, 3599, 522.0, 1658.0, 2002.5, 2482.5, 7.431672025723472, 3.2090558116459, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1907, 0, 0.0, 104.67226009438909, 61, 1076, 85.0, 149.0, 207.0, 451.0, 7.640622308052903, 10.901317570376262, 4.648542673747031], "isController": false}, {"data": ["GET_UI_dashboard-6", 1849, 0, 0.0, 647.1600865332605, 5, 3487, 461.0, 1551.0, 1931.0, 2460.0, 7.430178822583885, 1.5019990393309224, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1907, 1, 0.05243838489774515, 105.8804404824331, 1, 1077, 86.0, 150.0, 209.0, 458.52000000000044, 7.640805990840649, 55.72507882586215, 4.810288606203998], "isController": false}, {"data": ["GET_UI_dashboard-5", 1849, 0, 0.0, 663.2422931314231, 5, 3488, 458.0, 1624.0, 2063.0, 2500.5, 7.431940866028111, 1.4950974789079992, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1907, 0, 0.0, 699.5291033036169, 3, 5020, 510.0, 1691.4, 2162.7999999999997, 2979.120000000001, 7.640959066576914, 54.49406646797969, 4.484586327160865], "isController": false}, {"data": ["GET_UI_dashboard-4", 1849, 0, 0.0, 651.5819361817194, 4, 3491, 466.0, 1599.0, 1975.0, 2537.0, 7.430537136610967, 1.5020714719516313, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1907, 0, 0.0, 733.6743576297854, 7, 4330, 544.0, 1737.0, 2156.7999999999997, 3007.3600000000006, 7.640683534667548, 598.883341659655, 4.48442461360859], "isController": false}, {"data": ["GET_UI_dashboard-3", 1849, 0, 0.0, 102.21471065440787, 61, 1086, 85.0, 139.0, 195.0, 399.5, 7.429492150614972, 10.51302160765732, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 1849, 0, 0.0, 102.33315305570565, 62, 1092, 86.0, 139.0, 197.5, 385.5, 7.429492150614972, 54.11050044852194, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 1849, 0, 0.0, 634.8983234180639, 4, 3479, 431.0, 1592.0, 1954.0, 2512.5, 7.430059392254093, 1.4874630619258682, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 1849, 0, 0.0, 684.6522444564638, 4, 3776, 508.0, 1625.0, 2069.0, 2520.0, 7.430148964641493, 8.06867739129037, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1807, 0, 0.0, 61.50691754288885, 4, 426, 39.0, 145.0, 191.79999999999973, 304.84000000000015, 7.293672224711301, 3.6678968368691702, 5.2352041847293025], "isController": false}, {"data": ["GET_UI_dashboard", 1849, 0, 0.0, 2064.8128718226017, 75, 12405, 1966.0, 3938.0, 4571.5, 5780.0, 7.427074881303374, 610.025138146756, 0.0], "isController": false}, {"data": ["GET_UI_login", 1907, 39, 2.0450970110120608, 5031.976927110639, 247, 18615, 4268.0, 9739.8, 11338.599999999999, 14266.640000000003, 7.626474705058988, 39224.23916388597, 45.10404169166166], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 8, 10.0, 0.01647175094712568], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 31, 38.75, 0.063828034920112], "isController": false}, {"data": ["Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, 1.25, 0.00205896886839071], "isController": false}, {"data": ["Assertion failed", 39, 48.75, 0.08029978586723768], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 355,932)", 1, 1.25, 0.00205896886839071], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 48568, 80, "Assertion failed", 39, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 31, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 8, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 355,932)", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 1907, 2, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 1907, 3, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 1907, 35, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 31, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 3, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 355,932)", 1, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-2", 1907, 1, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 1907, 39, "Assertion failed", 39, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
