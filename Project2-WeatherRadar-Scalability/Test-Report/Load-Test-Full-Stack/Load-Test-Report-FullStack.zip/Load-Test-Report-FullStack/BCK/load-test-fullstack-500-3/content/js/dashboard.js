/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.85822306238185, "KoPercent": 0.14177693761814744};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3960696282293636, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.787, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.10485436893203884, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.11844660194174757, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.13495145631067962, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [9.70873786407767E-4, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.727, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.452, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.20194174757281552, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.4, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.37281553398058254, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.455, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.7883495145631068, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.448, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.7825242718446602, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.476, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.19514563106796118, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.451, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.1883495145631068, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.933, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.927, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.471, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.409, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.08064516129032258, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.141, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 12696, 18, 0.14177693761814744, 12798.975267800897, 4, 269150, 1823.5, 27366.9, 61429.64999999998, 217714.07000000004, 45.38743408704978, 19300.86001737197, 24.63204305009384], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 500, 0, 0.0, 151981.46000000005, 53906, 269150, 144257.5, 249727.0, 259132.15, 268471.94, 1.8450456833311193, 136.14058763782492, 0.8774777810373585], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 500, 0, 0.0, 536.9339999999994, 18, 4621, 236.5, 1348.7, 1659.75, 3865.98, 2.753834714840415, 0.6696336367141245, 1.6028178613719606], "isController": false}, {"data": ["GET_UI_login-7", 515, 1, 0.1941747572815534, 7095.860194174755, 13, 33663, 3635.0, 18869.8, 24622.0, 32340.159999999996, 1.992941504264508, 422.72877604972876, 1.1654717079702182], "isController": false}, {"data": ["GET_UI_login-6", 515, 0, 0.0, 7277.355339805828, 17, 46536, 3814.0, 18742.60000000001, 26804.199999999993, 39760.56, 2.022542512665436, 686.5998542922574, 1.1910089210324786], "isController": false}, {"data": ["GET_UI_login-9", 515, 2, 0.3883495145631068, 6745.411650485431, 18, 34575, 3741.0, 16830.8, 25130.0, 29442.919999999984, 1.981844000015393, 152.14539272980733, 1.1528713047267942], "isController": false}, {"data": ["GET_UI_login-8", 515, 6, 1.1650485436893203, 28235.831067961157, 1457, 118485, 20055.0, 67826.00000000006, 86801.39999999998, 107694.95999999998, 1.9410303667605147, 8633.91366004243, 1.124072121527346], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 500, 0, 0.0, 740.1299999999987, 24, 6747, 435.0, 1515.6000000000001, 2248.149999999999, 4923.82, 2.782151938881686, 75.16576843732089, 1.3639065169127016], "isController": false}, {"data": ["GET_UI_dashboard-9", 500, 0, 0.0, 4955.761999999998, 4, 34193, 1117.5, 17952.3, 22204.0, 26501.57, 2.743950960108441, 0.5546853991625462, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 515, 0, 0.0, 6077.083495145632, 8, 33915, 2899.0, 14909.800000000001, 24876.399999999998, 33130.92, 1.9843410446496001, 2.333150993904413, 1.1665754969522064], "isController": false}, {"data": ["GET_UI_dashboard-8", 500, 0, 0.0, 5899.747999999997, 31, 34153, 1384.0, 19409.0, 24899.95, 34036.71, 2.742596361123148, 25.242203398488282, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 515, 0, 0.0, 4624.82524271845, 4, 24949, 1787.0, 12373.80000000004, 15849.4, 24905.52, 2.0439671218958493, 2.2196205464337733, 1.1896527389159433], "isController": false}, {"data": ["GET_UI_dashboard-7", 500, 0, 0.0, 5349.549999999999, 9, 34062, 1122.0, 19363.400000000016, 22339.749999999996, 30074.90000000001, 2.743168139747958, 0.5545271532498314, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 515, 0, 0.0, 562.6446601941752, 64, 3355, 236.0, 1651.6000000000013, 2530.7999999999997, 3250.399999999999, 2.045127830417206, 2.917902109608924, 1.244252576513593], "isController": false}, {"data": ["GET_UI_dashboard-6", 500, 0, 0.0, 5848.703999999999, 14, 34459, 1162.0, 19943.2, 25061.899999999998, 33648.70000000001, 2.7416790042221857, 0.5542261268300708, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 515, 0, 0.0, 567.3669902912626, 68, 3349, 237.0, 1665.4000000000024, 2552.7999999999997, 3298.52, 2.045290272361178, 14.92223010235387, 1.2882931891337501], "isController": false}, {"data": ["GET_UI_dashboard-5", 500, 0, 0.0, 5257.672000000001, 9, 34525, 996.0, 18487.300000000003, 21958.25, 31995.24000000003, 2.7414685498727955, 0.5515063684314414, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 515, 0, 0.0, 5622.064077669905, 10, 33179, 2738.0, 14850.2, 18820.999999999996, 29025.879999999997, 1.9841116958568668, 14.15035909652607, 1.1645030558691178], "isController": false}, {"data": ["GET_UI_dashboard-4", 500, 0, 0.0, 5524.279999999998, 14, 34360, 1116.5, 19952.7, 22555.999999999996, 32615.370000000014, 2.740371704017933, 0.5539618581364376, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 515, 0, 0.0, 5992.236893203877, 11, 33675, 2798.0, 15049.800000000003, 25062.199999999993, 33501.72, 1.983569114865984, 155.47385185290392, 1.1641846074555238], "isController": false}, {"data": ["GET_UI_dashboard-3", 500, 0, 0.0, 261.3460000000002, 66, 2191, 139.0, 610.5000000000002, 922.95, 1829.6700000000012, 2.741994746338066, 3.8800296752381427, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 500, 0, 0.0, 268.01399999999995, 69, 2173, 140.0, 675.4000000000005, 938.55, 1805.1500000000008, 2.7418293485413465, 19.96930007951305, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 500, 0, 0.0, 5225.056, 9, 34526, 1069.5, 19358.7, 22057.999999999996, 28614.590000000004, 2.741904526884374, 0.5489164336047819, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 500, 0, 0.0, 5572.176000000001, 13, 34122, 1632.0, 18086.500000000015, 22191.449999999997, 31129.91000000001, 2.7330767885254503, 2.9679505750393567, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 31, 0, 0.0, 6812.451612903226, 330, 15748, 5950.0, 13759.0, 15457.599999999999, 15748.0, 1.9283403831798955, 3.7829343819980092, 1.3841115055051008], "isController": false}, {"data": ["GET_UI_dashboard", 500, 0, 0.0, 17081.852000000024, 209, 60338, 15250.5, 42065.8, 46718.049999999996, 54156.36, 2.7302263357632346, 55.144844906080216, 0.0], "isController": false}, {"data": ["GET_UI_login", 515, 9, 1.7475728155339805, 34060.02330097086, 1619, 126177, 26296.0, 82496.00000000009, 97741.0, 115566.23999999999, 1.936527036173573, 10017.580372334925, 11.457512003412424], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 4, 22.22222222222222, 0.0315059861373661], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, 22.22222222222222, 0.0315059861373661], "isController": false}, {"data": ["Assertion failed", 9, 50.0, 0.07088846880907372], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,144,652)", 1, 5.555555555555555, 0.007876496534341524], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 12696, 18, "Assertion failed", 9, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,144,652)", 1, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 515, 1, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 515, 2, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 515, 6, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,144,652)", 1, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 515, 9, "Assertion failed", 9, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
