/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 77.18915845337376, "KoPercent": 22.810841546626232};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.33045868081880214, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.891846921797005, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9147963424771405, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.010321100917431193, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.01834862385321101, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.006880733944954129, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.7793017456359103, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.024193548387096774, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.05619266055045872, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.0228494623655914, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.10722477064220183, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.0228494623655914, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9260321100917431, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.025537634408602152, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9225917431192661, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.024193548387096774, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.045871559633027525, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.0228494623655914, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.040137614678899085, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9798387096774194, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9838709677419355, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.025537634408602152, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.024193548387096774, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.997504159733777, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.0014775413711583924, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 21104, 4814, 22.810841546626232, 15861.741565580023, 2, 168679, 7577.0, 51812.0, 51994.9, 93664.6700000007, 79.14316572662906, 27786.088279468677, 43.297466761951725], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1202, 0, 0.0, 282.12063227953405, 6, 6652, 217.0, 639.7, 758.6999999999998, 963.6400000000003, 5.860527252426853, 432.43136536998844, 2.787184347589724], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1203, 0, 0.0, 229.79634247714085, 4, 4200, 66.0, 716.0, 961.3999999999999, 1178.8000000000002, 5.857434998539293, 1.424317690074496, 3.409210213993573], "isController": false}, {"data": ["GET_UI_login-7", 872, 182, 20.871559633027523, 19764.444954128445, 375, 124675, 10608.0, 51821.0, 57915.39999999991, 83673.36999999995, 4.17632521695818, 704.6116531282329, 1.936324809862258], "isController": false}, {"data": ["GET_UI_login-6", 872, 159, 18.23394495412844, 17186.993119266062, 332, 73851, 10167.5, 51816.0, 51822.35, 54195.03999999999, 5.903459481416289, 1641.4904852096167, 2.8424771829090782], "isController": false}, {"data": ["GET_UI_login-9", 872, 293, 33.60091743119266, 24142.14908256881, 228, 122150, 15495.5, 52134.2, 54398.24999999999, 84567.04999999996, 3.722677595628415, 193.62194707484844, 1.4435064597207992], "isController": false}, {"data": ["GET_UI_login-8", 872, 182, 20.871559633027523, 36117.947247706434, 3609, 124641, 39557.0, 51846.1, 62917.599999999984, 102986.72, 4.182474854788502, 14896.898257934172, 1.9391760476571904], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1203, 0, 0.0, 513.1280133000837, 13, 2065, 390.0, 1279.2000000000003, 1421.3999999999999, 1696.2400000000007, 5.862087448895559, 382.86867148554944, 2.873796776704659], "isController": false}, {"data": ["GET_UI_dashboard-9", 372, 137, 36.82795698924731, 13817.854838709676, 105, 29653, 9299.0, 25922.4, 27224.799999999996, 29005.55, 2.829047934110561, 2.4592786664499253, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 872, 159, 18.23394495412844, 16548.41284403668, 121, 70915, 9491.5, 51815.0, 51824.0, 55986.329999999994, 6.07204283854076, 8.761229492928715, 2.9188004625406485], "isController": false}, {"data": ["GET_UI_dashboard-8", 372, 56, 15.053763440860216, 11630.416666666673, 233, 31887, 9050.0, 25909.7, 25956.7, 30393.999999999985, 3.492433061699651, 1.6612821078523414, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 872, 0, 0.0, 8152.999999999998, 11, 24140, 8306.5, 17147.0, 17483.05, 17887.89, 10.241473268815183, 11.121599877853988, 5.960857488490087], "isController": false}, {"data": ["GET_UI_dashboard-7", 372, 56, 15.053763440860216, 11561.809139784948, 193, 31343, 8971.0, 25908.7, 25944.0, 29903.93999999999, 3.492301915133308, 1.6583226741457004, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 872, 0, 0.0, 248.5699541284404, 60, 1610, 121.0, 600.6000000000004, 1173.35, 1592.54, 10.238827701195312, 14.60832741352183, 6.229286775238945], "isController": false}, {"data": ["GET_UI_dashboard-6", 372, 56, 15.053763440860216, 11316.392473118278, 81, 30163, 8884.0, 25908.0, 25922.4, 28594.529999999995, 3.4920724323410965, 1.658213704037474, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 872, 0, 0.0, 251.35321100917423, 63, 1621, 124.0, 587.9000000000008, 1184.0499999999997, 1596.27, 10.2379862162892, 74.69530763857091, 6.448731552252474], "isController": false}, {"data": ["GET_UI_dashboard-5", 372, 56, 15.053763440860216, 11320.793010752688, 118, 30578, 8874.5, 25908.7, 25921.7, 30022.159999999996, 3.4922363455436436, 1.6553945429113235, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 872, 158, 18.119266055045873, 16602.558486238544, 123, 69045, 9559.5, 51815.0, 51821.35, 52822.899999999965, 6.3724057293189125, 40.261251164681376, 3.0623841027842733], "isController": false}, {"data": ["GET_UI_dashboard-4", 372, 56, 15.053763440860216, 11326.889784946234, 203, 30354, 8870.5, 25908.0, 25920.45, 30000.719999999998, 3.4920068713683596, 1.6581825723511907, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 872, 159, 18.23394495412844, 16751.217889908254, 114, 71078, 9684.5, 51815.0, 51823.0, 54522.96999999997, 6.371846958758367, 411.4328771912358, 3.0578268973964575], "isController": false}, {"data": ["GET_UI_dashboard-3", 372, 0, 0.0, 144.51612903225808, 67, 1119, 98.0, 233.09999999999997, 393.1999999999989, 836.9399999999996, 4.610008179046769, 6.523341651795672, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 372, 0, 0.0, 143.21774193548373, 68, 1077, 99.5, 235.7, 377.34999999999997, 821.7499999999995, 4.610008179046769, 33.57562597590899, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 372, 56, 15.053763440860216, 11319.169354838707, 119, 32691, 8911.0, 25908.0, 25925.05, 30087.629999999997, 3.4921052137506337, 1.6524354969678765, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 372, 0, 0.0, 8422.209677419349, 146, 20357, 4909.0, 17421.4, 18089.35, 20230.86, 4.429309646845903, 4.809953444621723, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1202, 0, 0.0, 80.75540765391011, 2, 789, 34.5, 211.70000000000005, 311.0, 464.7600000000002, 5.865818188916434, 5.6724700990283825, 4.210328485208573], "isController": false}, {"data": ["GET_UI_dashboard", 1692, 1457, 86.11111111111111, 27613.19739952721, 659, 74412, 25905.0, 30024.60000000001, 59240.5, 71056.98, 6.474398956137095, 28.791993043225798, 0.0], "isController": false}, {"data": ["GET_UI_login", 2162, 1592, 73.63552266419981, 54122.579555966746, 4780, 168679, 51810.0, 87965.40000000001, 118412.0, 121850.93999999999, 8.10782431297252, 13559.260251269425, 16.540366204491928], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 41, 0.8516825924387204, 0.194275966641395], "isController": false}, {"data": ["Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 1793, 37.245533859576234, 8.496019711902957], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 2541, 52.783547985043626, 12.040371493555725], "isController": false}, {"data": ["Assertion failed", 439, 9.119235562941421, 2.0801743745261563], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 21104, 4814, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 2541, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 1793, "Assertion failed", 439, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 41, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 872, 182, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 181, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-6", 872, 159, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 159, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-9", 872, 293, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 254, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 39, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 872, 182, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 181, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-9", 372, 137, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 137, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-1", 872, 159, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 159, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-8", 372, 56, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 56, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-7", 372, 56, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 56, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-6", 372, 56, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 56, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-5", 372, 56, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 56, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-5", 872, 158, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 158, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-4", 372, 56, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 56, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-4", 872, 159, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 159, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-1", 372, 56, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 56, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard", 1692, 1457, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 1320, "Assertion failed", 137, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login", 2162, 1592, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 1290, "Assertion failed", 302, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
