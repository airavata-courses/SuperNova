/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.80859001152366, "KoPercent": 0.19140998847633742};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7366843102404343, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9834905660377359, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9922037422037422, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.6719840478564307, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.6532901296111665, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.7051345962113659, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.1321036889332004, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.6789802289281998, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.7510245901639344, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.7524925224327019, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.7118340163934426, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.752741774675972, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.7548668032786885, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9862911266201396, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.7671618852459017, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9862911266201396, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.7722848360655737, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.7507477567298105, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.7630635245901639, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.7352941176470589, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9877049180327869, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9874487704918032, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.7617827868852459, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.7451331967213115, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9976402726796014, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.33709016393442626, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.07502492522432702, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 51199, 98, 0.19140998847633742, 861.4531729135293, 1, 25984, 200.0, 1818.9000000000015, 2991.9500000000007, 6475.990000000002, 204.64538099958432, 85595.93680457433, 112.14386445950781], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1908, 0, 0.0, 179.5885744234801, 12, 1286, 148.0, 328.10000000000014, 428.54999999999995, 817.3700000000006, 7.697366032346689, 567.9663893281748, 3.6607590407742547], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1924, 0, 0.0, 157.02546777546766, 8, 1205, 131.0, 281.0, 359.75, 586.5, 7.74554047689019, 1.8834370886188059, 4.508146605689993], "isController": false}, {"data": ["GET_UI_login-7", 2006, 10, 0.4985044865403789, 802.1081754735791, 13, 5071, 474.0, 2001.6, 2702.9999999999973, 3802.760000000002, 8.025059307828634, 1697.0724393432433, 4.6787425940224106], "isController": false}, {"data": ["GET_UI_login-6", 2006, 0, 0.0, 838.0164506480564, 14, 5734, 530.0, 2052.3999999999996, 2721.199999999999, 3712.0, 8.026986038806434, 2724.95011112884, 4.7268286927737115], "isController": false}, {"data": ["GET_UI_login-9", 2006, 8, 0.3988035892323031, 725.4915254237288, 5, 5205, 379.0, 1924.3999999999996, 2503.449999999998, 3906.8700000000035, 8.026118895388382, 616.0995448110801, 4.668435591996287], "isController": false}, {"data": ["GET_UI_login-8", 2006, 32, 1.5952143569292123, 3869.9955134596357, 117, 25019, 3138.5, 7523.0, 9552.499999999998, 16215.040000000008, 8.021304841573231, 35524.41377743953, 4.625008497144959], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1922, 0, 0.0, 672.9989594172732, 96, 2752, 579.0, 1205.7, 1444.9499999999994, 2125.7, 7.732166132951418, 1126.7128069910327, 3.7905736315836056], "isController": false}, {"data": ["GET_UI_dashboard-9", 1952, 0, 0.0, 631.3171106557386, 3, 4889, 302.5, 1643.2000000000003, 2348.499999999999, 3586.6400000000003, 7.843515437902824, 4.056273054390279, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 2006, 0, 0.0, 640.6455633100688, 4, 5129, 287.5, 1759.0, 2391.299999999997, 3633.670000000001, 8.02762848807661, 9.438735058246328, 4.719367529123164], "isController": false}, {"data": ["GET_UI_dashboard-8", 1952, 0, 0.0, 757.3652663934431, 15, 9122, 387.0, 1918.7, 2622.8999999999987, 3915.2200000000007, 7.850992032369255, 544.6064681445596, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 2006, 0, 0.0, 625.9411764705873, 3, 5262, 281.0, 1757.0, 2325.95, 3702.370000000001, 8.025476687710539, 8.715166090560663, 4.671078228394024], "isController": false}, {"data": ["GET_UI_dashboard-7", 1952, 0, 0.0, 627.0404713114749, 5, 5128, 316.0, 1601.3000000000004, 2280.149999999999, 3423.88, 7.846605298066487, 9.267502361619165, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 2006, 0, 0.0, 113.92671984047873, 62, 1088, 80.0, 135.29999999999995, 328.9499999999996, 796.7200000000003, 8.025573012310412, 11.450548995103041, 4.882746080731824], "isController": false}, {"data": ["GET_UI_dashboard-6", 1952, 0, 0.0, 609.7704918032787, 7, 5246, 277.0, 1620.2000000000003, 2313.0, 3436.29, 7.841467382789747, 1.5851403791381617, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 2006, 1, 0.049850448654037885, 113.4007976071785, 1, 1078, 81.0, 133.29999999999995, 321.59999999999945, 764.8600000000001, 8.025508795653584, 58.53186336531268, 5.052610046938825], "isController": false}, {"data": ["GET_UI_dashboard-5", 1952, 0, 0.0, 597.8432377049188, 4, 4196, 272.0, 1577.8000000000002, 2367.4499999999994, 3439.4700000000003, 7.84417734591938, 1.5780278645111252, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 2006, 0, 0.0, 633.8344965104691, 5, 5216, 285.5, 1786.9999999999995, 2338.5999999999995, 3616.020000000001, 8.025701448707126, 57.23798601553529, 4.7103970416728345], "isController": false}, {"data": ["GET_UI_dashboard-4", 1952, 0, 0.0, 613.0968237704917, 4, 5246, 277.0, 1690.4, 2414.7, 3479.100000000001, 7.839987147562052, 1.584841151899751, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 2006, 0, 0.0, 679.1869391824525, 8, 5190, 321.0, 1852.3, 2435.0, 3751.3200000000015, 8.025637229994919, 629.0563431189962, 4.710359350807565], "isController": false}, {"data": ["GET_UI_dashboard-3", 1952, 0, 0.0, 111.41854508196727, 60, 1083, 80.0, 141.70000000000005, 307.6999999999998, 672.47, 7.846889182789908, 11.103654712756422, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 1952, 0, 0.0, 112.66188524590177, 61, 2238, 81.0, 140.4000000000001, 299.3499999999999, 682.47, 7.846826095520636, 57.15002834022744, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 1952, 0, 0.0, 611.0742827868858, 5, 4097, 286.5, 1672.9000000000008, 2397.499999999999, 3448.6400000000003, 7.849287250939944, 1.571390514104188, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 1952, 0, 0.0, 627.0373975409839, 4, 5197, 298.0, 1725.5000000000002, 2218.499999999999, 3368.2200000000007, 7.846195278616304, 8.520477685372393, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1907, 0, 0.0, 91.24016780283172, 4, 1150, 71.0, 180.20000000000005, 223.5999999999999, 335.9200000000001, 7.698052275708951, 3.854237624886467, 5.525457443990312], "isController": false}, {"data": ["GET_UI_dashboard", 1952, 0, 0.0, 2064.2151639344297, 89, 10816, 1696.5, 4338.1, 5089.4, 6507.490000000002, 7.836650795307645, 639.909023013136, 0.0], "isController": false}, {"data": ["GET_UI_login", 2006, 47, 2.3429710867397806, 4726.647557328011, 305, 25984, 4166.0, 8538.599999999999, 11309.299999999987, 17228.390000000003, 8.018098679371981, 41316.93352989075, 47.40177245172553], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 20, 20.408163265306122, 0.039063262954354576], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 29, 29.591836734693878, 0.05664173128381414], "isController": false}, {"data": ["Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, 1.0204081632653061, 0.001953163147717729], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, 1.0204081632653061, 0.001953163147717729], "isController": false}, {"data": ["Assertion failed", 47, 47.95918367346939, 0.09179866794273325], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 51199, 98, "Assertion failed", 47, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 29, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 20, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 2006, 10, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 8, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 2006, 8, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 7, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 2006, 32, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 27, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 5, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-2", 2006, 1, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 2006, 47, "Assertion failed", 47, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
