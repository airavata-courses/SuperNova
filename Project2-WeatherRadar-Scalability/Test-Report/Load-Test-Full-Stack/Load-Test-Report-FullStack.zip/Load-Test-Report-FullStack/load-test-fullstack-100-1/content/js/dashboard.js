/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.82354238658922, "KoPercent": 0.17645761341077862};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6583707080361738, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9992603550295858, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9990191270230505, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.5309568480300187, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.5729362101313321, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.524859287054409, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.09075984990619138, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.9599311701081613, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.5860240963855422, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.6444652908067542, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.553012048192771, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.598968105065666, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.571566265060241, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9929643527204502, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.6065060240963855, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9887429643527205, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.6086746987951808, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.6437617260787992, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.6103614457831326, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.6238273921200751, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9925301204819277, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9898795180722891, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.6118072289156626, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.6180722891566265, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [1.0, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.1908433734939759, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.06214821763602251, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 54404, 96, 0.17645761341077862, 930.299150797744, 3, 11552, 487.0, 1780.0, 3341.5000000000073, 6003.980000000003, 189.24117780058089, 78903.83792782122, 103.71635558159555], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 2028, 0, 0.0, 102.41765285996078, 7, 1086, 82.0, 200.0, 261.0, 367.71000000000004, 7.112570099849542, 524.8159878949527, 3.382638318971413], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 2039, 0, 0.0, 80.57233938204988, 5, 578, 65.0, 161.0, 196.0, 274.1999999999998, 7.136257367249514, 1.7352813324659462, 4.1535247957819434], "isController": false}, {"data": ["GET_UI_login-7", 2132, 6, 0.28142589118198874, 988.5098499061942, 39, 6329, 914.5, 1723.7, 2012.4499999999994, 3386.1600000000035, 7.441977359913154, 1577.1721661385666, 4.348261938753783], "isController": false}, {"data": ["GET_UI_login-6", 2132, 0, 0.0, 889.4015009380867, 22, 5235, 866.0, 1543.7, 1717.7499999999995, 2385.470000000003, 7.444030111311294, 2527.051944652484, 4.383545075313194], "isController": false}, {"data": ["GET_UI_login-9", 2132, 7, 0.32833020637898686, 994.6167917448407, 31, 6889, 962.0, 1714.0, 1932.35, 3200.67, 7.441691623559307, 571.6326254051131, 4.331562953761684], "isController": false}, {"data": ["GET_UI_login-8", 2132, 36, 1.6885553470919326, 3513.677298311441, 120, 10412, 3554.5, 5730.7, 6284.499999999999, 7224.060000000001, 7.430487303346507, 32876.6218624042, 4.280284812111834], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 2034, 0, 0.0, 259.56145526057026, 13, 860, 246.5, 467.0, 543.25, 662.3000000000002, 7.1314872341469915, 770.3003784822537, 3.496100187052529], "isController": false}, {"data": ["GET_UI_dashboard-9", 2075, 0, 0.0, 835.7310843373494, 16, 2218, 782.0, 1558.4, 1688.0, 1980.2399999999998, 7.256386494378486, 3.348360646780088, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 2132, 0, 0.0, 742.9404315196998, 11, 3890, 710.0, 1409.7, 1574.0, 1908.6800000000003, 7.44527790582352, 8.754018162706561, 4.377009081353281], "isController": false}, {"data": ["GET_UI_dashboard-8", 2075, 0, 0.0, 940.0877108433738, 30, 6233, 867.0, 1638.2000000000003, 1850.1999999999998, 4304.439999999999, 7.256310367256731, 536.5553983233551, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 2132, 0, 0.0, 828.4516885553468, 13, 3454, 780.5, 1530.7, 1694.0, 1932.710000000001, 7.44655212761127, 8.086490201077863, 4.334126043023747], "isController": false}, {"data": ["GET_UI_dashboard-7", 2075, 0, 0.0, 857.4110843373487, 16, 2239, 824.0, 1570.0, 1742.1999999999998, 2043.4799999999996, 7.256513376464417, 5.921943986055255, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 2132, 0, 0.0, 125.32129455909944, 62, 1963, 90.0, 181.0, 389.39999999999964, 601.6800000000003, 7.4467862157612, 10.624760411354602, 4.530613098065652], "isController": false}, {"data": ["GET_UI_dashboard-6", 2075, 0, 0.0, 789.8756626506014, 17, 2185, 732.0, 1532.0, 1670.0, 1946.4399999999987, 7.254230177597539, 1.4664312956666898, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 2132, 0, 0.0, 134.08677298311443, 62, 1895, 91.0, 223.70000000000005, 421.3499999999999, 746.0100000000002, 7.44644809315744, 54.32852900779223, 4.690389668053271], "isController": false}, {"data": ["GET_UI_dashboard-5", 2075, 0, 0.0, 790.0183132530141, 13, 2176, 730.0, 1530.0, 1667.1999999999998, 1948.7199999999993, 7.253849784132422, 1.4592705620422646, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 2132, 0, 0.0, 752.5576923076922, 12, 3962, 708.0, 1433.1000000000001, 1602.35, 2026.4100000000017, 7.4447579406095485, 53.09479222682767, 4.369433127252284], "isController": false}, {"data": ["GET_UI_dashboard-4", 2075, 0, 0.0, 788.161445783132, 12, 2184, 728.0, 1525.4, 1668.0, 1938.9599999999991, 7.253925859633913, 1.4663697782658396, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 2132, 0, 0.0, 782.0046904315191, 19, 4016, 740.0, 1452.7, 1610.6999999999998, 2039.6900000000005, 7.44423804801743, 583.4857755956787, 4.36912799497898], "isController": false}, {"data": ["GET_UI_dashboard-3", 2075, 0, 0.0, 122.21927710843367, 61, 1133, 88.0, 172.0, 381.39999999999964, 551.0799999999963, 7.254509158162285, 10.265413838063623, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 2075, 0, 0.0, 127.56674698795176, 59, 1081, 89.0, 208.0, 410.9999999999991, 601.8399999999965, 7.254407708201501, 52.83532489039726, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 2075, 0, 0.0, 787.0120481927718, 12, 2181, 728.0, 1525.0, 1668.1999999999998, 1944.8799999999974, 7.254001936731119, 1.4522171845994918, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 2075, 0, 0.0, 789.4260240963856, 11, 2200, 749.0, 1464.8000000000002, 1611.5999999999995, 1855.4799999999996, 7.248705713028107, 7.871641360241461, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 2026, 0, 0.0, 52.78775913129317, 3, 375, 39.0, 119.0, 144.0, 231.73000000000002, 7.111841250785427, 4.283204763590953, 5.104690741530555], "isController": false}, {"data": ["GET_UI_dashboard", 2075, 0, 0.0, 2438.979759036143, 94, 8047, 2470.0, 4088.0, 4342.2, 5764.639999999998, 7.242835701071591, 621.5124253082569, 0.0], "isController": false}, {"data": ["GET_UI_login", 2132, 47, 2.204502814258912, 4496.623358348976, 405, 11552, 4598.0, 7234.4, 7841.049999999999, 8803.400000000001, 7.426837637206646, 38242.81256504361, 43.917100853198036], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 20, 20.833333333333332, 0.036762002793912216], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 29, 30.208333333333332, 0.053304904051172705], "isController": false}, {"data": ["Assertion failed", 47, 48.958333333333336, 0.0863907065656937], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 54404, 96, "Assertion failed", 47, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 29, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 20, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 2132, 6, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 2132, 7, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 7, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 2132, 36, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 27, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 9, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 2132, 47, "Assertion failed", 47, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
