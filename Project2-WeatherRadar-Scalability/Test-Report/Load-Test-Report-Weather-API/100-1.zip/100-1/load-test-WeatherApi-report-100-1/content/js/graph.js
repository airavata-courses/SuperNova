/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 11.0, "minX": 0.0, "maxY": 2887.0, "series": [{"data": [[0.0, 11.0], [0.1, 19.0], [0.2, 28.0], [0.3, 32.0], [0.4, 33.0], [0.5, 35.0], [0.6, 35.0], [0.7, 36.0], [0.8, 36.0], [0.9, 36.0], [1.0, 37.0], [1.1, 37.0], [1.2, 37.0], [1.3, 37.0], [1.4, 37.0], [1.5, 38.0], [1.6, 38.0], [1.7, 38.0], [1.8, 38.0], [1.9, 38.0], [2.0, 38.0], [2.1, 39.0], [2.2, 39.0], [2.3, 39.0], [2.4, 39.0], [2.5, 39.0], [2.6, 39.0], [2.7, 39.0], [2.8, 39.0], [2.9, 39.0], [3.0, 40.0], [3.1, 40.0], [3.2, 40.0], [3.3, 40.0], [3.4, 40.0], [3.5, 40.0], [3.6, 40.0], [3.7, 40.0], [3.8, 40.0], [3.9, 41.0], [4.0, 41.0], [4.1, 41.0], [4.2, 41.0], [4.3, 41.0], [4.4, 41.0], [4.5, 41.0], [4.6, 41.0], [4.7, 42.0], [4.8, 42.0], [4.9, 42.0], [5.0, 42.0], [5.1, 42.0], [5.2, 42.0], [5.3, 42.0], [5.4, 43.0], [5.5, 43.0], [5.6, 43.0], [5.7, 43.0], [5.8, 43.0], [5.9, 43.0], [6.0, 43.0], [6.1, 43.0], [6.2, 44.0], [6.3, 44.0], [6.4, 44.0], [6.5, 44.0], [6.6, 44.0], [6.7, 44.0], [6.8, 44.0], [6.9, 45.0], [7.0, 45.0], [7.1, 45.0], [7.2, 45.0], [7.3, 45.0], [7.4, 45.0], [7.5, 46.0], [7.6, 46.0], [7.7, 46.0], [7.8, 46.0], [7.9, 47.0], [8.0, 47.0], [8.1, 47.0], [8.2, 47.0], [8.3, 47.0], [8.4, 48.0], [8.5, 48.0], [8.6, 48.0], [8.7, 49.0], [8.8, 49.0], [8.9, 49.0], [9.0, 50.0], [9.1, 50.0], [9.2, 51.0], [9.3, 51.0], [9.4, 51.0], [9.5, 52.0], [9.6, 52.0], [9.7, 53.0], [9.8, 53.0], [9.9, 54.0], [10.0, 55.0], [10.1, 55.0], [10.2, 56.0], [10.3, 57.0], [10.4, 58.0], [10.5, 59.0], [10.6, 61.0], [10.7, 63.0], [10.8, 65.0], [10.9, 66.0], [11.0, 67.0], [11.1, 68.0], [11.2, 69.0], [11.3, 70.0], [11.4, 70.0], [11.5, 71.0], [11.6, 72.0], [11.7, 72.0], [11.8, 72.0], [11.9, 73.0], [12.0, 73.0], [12.1, 74.0], [12.2, 74.0], [12.3, 74.0], [12.4, 74.0], [12.5, 75.0], [12.6, 75.0], [12.7, 75.0], [12.8, 76.0], [12.9, 76.0], [13.0, 76.0], [13.1, 76.0], [13.2, 77.0], [13.3, 77.0], [13.4, 77.0], [13.5, 77.0], [13.6, 78.0], [13.7, 78.0], [13.8, 78.0], [13.9, 78.0], [14.0, 78.0], [14.1, 79.0], [14.2, 79.0], [14.3, 79.0], [14.4, 79.0], [14.5, 80.0], [14.6, 80.0], [14.7, 80.0], [14.8, 80.0], [14.9, 81.0], [15.0, 81.0], [15.1, 81.0], [15.2, 82.0], [15.3, 82.0], [15.4, 82.0], [15.5, 82.0], [15.6, 83.0], [15.7, 83.0], [15.8, 83.0], [15.9, 83.0], [16.0, 84.0], [16.1, 84.0], [16.2, 84.0], [16.3, 85.0], [16.4, 85.0], [16.5, 85.0], [16.6, 86.0], [16.7, 86.0], [16.8, 86.0], [16.9, 87.0], [17.0, 87.0], [17.1, 88.0], [17.2, 88.0], [17.3, 89.0], [17.4, 89.0], [17.5, 89.0], [17.6, 90.0], [17.7, 90.0], [17.8, 91.0], [17.9, 91.0], [18.0, 92.0], [18.1, 92.0], [18.2, 92.0], [18.3, 93.0], [18.4, 94.0], [18.5, 94.0], [18.6, 94.0], [18.7, 95.0], [18.8, 95.0], [18.9, 96.0], [19.0, 97.0], [19.1, 97.0], [19.2, 98.0], [19.3, 98.0], [19.4, 99.0], [19.5, 99.0], [19.6, 100.0], [19.7, 101.0], [19.8, 101.0], [19.9, 102.0], [20.0, 103.0], [20.1, 103.0], [20.2, 104.0], [20.3, 104.0], [20.4, 105.0], [20.5, 105.0], [20.6, 106.0], [20.7, 106.0], [20.8, 107.0], [20.9, 107.0], [21.0, 108.0], [21.1, 108.0], [21.2, 109.0], [21.3, 109.0], [21.4, 110.0], [21.5, 110.0], [21.6, 111.0], [21.7, 111.0], [21.8, 112.0], [21.9, 112.0], [22.0, 113.0], [22.1, 113.0], [22.2, 114.0], [22.3, 114.0], [22.4, 114.0], [22.5, 115.0], [22.6, 116.0], [22.7, 116.0], [22.8, 117.0], [22.9, 117.0], [23.0, 118.0], [23.1, 118.0], [23.2, 118.0], [23.3, 119.0], [23.4, 119.0], [23.5, 119.0], [23.6, 120.0], [23.7, 120.0], [23.8, 121.0], [23.9, 121.0], [24.0, 122.0], [24.1, 122.0], [24.2, 122.0], [24.3, 123.0], [24.4, 123.0], [24.5, 123.0], [24.6, 124.0], [24.7, 124.0], [24.8, 125.0], [24.9, 125.0], [25.0, 125.0], [25.1, 126.0], [25.2, 126.0], [25.3, 127.0], [25.4, 127.0], [25.5, 128.0], [25.6, 128.0], [25.7, 128.0], [25.8, 129.0], [25.9, 129.0], [26.0, 130.0], [26.1, 130.0], [26.2, 131.0], [26.3, 131.0], [26.4, 131.0], [26.5, 132.0], [26.6, 132.0], [26.7, 133.0], [26.8, 133.0], [26.9, 134.0], [27.0, 134.0], [27.1, 135.0], [27.2, 135.0], [27.3, 135.0], [27.4, 136.0], [27.5, 136.0], [27.6, 137.0], [27.7, 137.0], [27.8, 137.0], [27.9, 138.0], [28.0, 138.0], [28.1, 139.0], [28.2, 139.0], [28.3, 139.0], [28.4, 140.0], [28.5, 140.0], [28.6, 141.0], [28.7, 141.0], [28.8, 141.0], [28.9, 142.0], [29.0, 143.0], [29.1, 143.0], [29.2, 144.0], [29.3, 144.0], [29.4, 144.0], [29.5, 145.0], [29.6, 145.0], [29.7, 146.0], [29.8, 146.0], [29.9, 147.0], [30.0, 147.0], [30.1, 147.0], [30.2, 148.0], [30.3, 148.0], [30.4, 149.0], [30.5, 149.0], [30.6, 149.0], [30.7, 150.0], [30.8, 150.0], [30.9, 151.0], [31.0, 151.0], [31.1, 152.0], [31.2, 152.0], [31.3, 152.0], [31.4, 153.0], [31.5, 153.0], [31.6, 154.0], [31.7, 154.0], [31.8, 155.0], [31.9, 155.0], [32.0, 156.0], [32.1, 156.0], [32.2, 157.0], [32.3, 157.0], [32.4, 157.0], [32.5, 158.0], [32.6, 159.0], [32.7, 159.0], [32.8, 160.0], [32.9, 160.0], [33.0, 161.0], [33.1, 161.0], [33.2, 162.0], [33.3, 162.0], [33.4, 163.0], [33.5, 163.0], [33.6, 164.0], [33.7, 164.0], [33.8, 165.0], [33.9, 165.0], [34.0, 165.0], [34.1, 166.0], [34.2, 166.0], [34.3, 167.0], [34.4, 167.0], [34.5, 168.0], [34.6, 168.0], [34.7, 168.0], [34.8, 169.0], [34.9, 169.0], [35.0, 170.0], [35.1, 170.0], [35.2, 171.0], [35.3, 171.0], [35.4, 172.0], [35.5, 172.0], [35.6, 173.0], [35.7, 173.0], [35.8, 174.0], [35.9, 174.0], [36.0, 175.0], [36.1, 175.0], [36.2, 175.0], [36.3, 176.0], [36.4, 176.0], [36.5, 176.0], [36.6, 177.0], [36.7, 177.0], [36.8, 178.0], [36.9, 178.0], [37.0, 179.0], [37.1, 179.0], [37.2, 179.0], [37.3, 180.0], [37.4, 180.0], [37.5, 180.0], [37.6, 181.0], [37.7, 181.0], [37.8, 182.0], [37.9, 182.0], [38.0, 183.0], [38.1, 183.0], [38.2, 183.0], [38.3, 184.0], [38.4, 184.0], [38.5, 184.0], [38.6, 185.0], [38.7, 185.0], [38.8, 186.0], [38.9, 186.0], [39.0, 186.0], [39.1, 187.0], [39.2, 187.0], [39.3, 188.0], [39.4, 188.0], [39.5, 189.0], [39.6, 189.0], [39.7, 190.0], [39.8, 190.0], [39.9, 191.0], [40.0, 191.0], [40.1, 192.0], [40.2, 192.0], [40.3, 192.0], [40.4, 193.0], [40.5, 193.0], [40.6, 193.0], [40.7, 194.0], [40.8, 194.0], [40.9, 195.0], [41.0, 195.0], [41.1, 195.0], [41.2, 196.0], [41.3, 196.0], [41.4, 197.0], [41.5, 197.0], [41.6, 198.0], [41.7, 198.0], [41.8, 199.0], [41.9, 199.0], [42.0, 200.0], [42.1, 200.0], [42.2, 201.0], [42.3, 201.0], [42.4, 202.0], [42.5, 202.0], [42.6, 202.0], [42.7, 203.0], [42.8, 203.0], [42.9, 204.0], [43.0, 204.0], [43.1, 204.0], [43.2, 205.0], [43.3, 205.0], [43.4, 206.0], [43.5, 206.0], [43.6, 207.0], [43.7, 207.0], [43.8, 208.0], [43.9, 208.0], [44.0, 209.0], [44.1, 209.0], [44.2, 210.0], [44.3, 210.0], [44.4, 210.0], [44.5, 211.0], [44.6, 211.0], [44.7, 212.0], [44.8, 212.0], [44.9, 213.0], [45.0, 213.0], [45.1, 214.0], [45.2, 214.0], [45.3, 215.0], [45.4, 215.0], [45.5, 216.0], [45.6, 216.0], [45.7, 217.0], [45.8, 217.0], [45.9, 218.0], [46.0, 218.0], [46.1, 219.0], [46.2, 219.0], [46.3, 220.0], [46.4, 220.0], [46.5, 221.0], [46.6, 221.0], [46.7, 221.0], [46.8, 222.0], [46.9, 222.0], [47.0, 223.0], [47.1, 223.0], [47.2, 224.0], [47.3, 224.0], [47.4, 225.0], [47.5, 225.0], [47.6, 226.0], [47.7, 226.0], [47.8, 227.0], [47.9, 227.0], [48.0, 228.0], [48.1, 228.0], [48.2, 229.0], [48.3, 229.0], [48.4, 230.0], [48.5, 230.0], [48.6, 231.0], [48.7, 231.0], [48.8, 232.0], [48.9, 232.0], [49.0, 232.0], [49.1, 233.0], [49.2, 233.0], [49.3, 234.0], [49.4, 234.0], [49.5, 235.0], [49.6, 235.0], [49.7, 236.0], [49.8, 236.0], [49.9, 237.0], [50.0, 237.0], [50.1, 238.0], [50.2, 238.0], [50.3, 239.0], [50.4, 239.0], [50.5, 240.0], [50.6, 241.0], [50.7, 241.0], [50.8, 242.0], [50.9, 243.0], [51.0, 243.0], [51.1, 244.0], [51.2, 244.0], [51.3, 245.0], [51.4, 245.0], [51.5, 246.0], [51.6, 246.0], [51.7, 247.0], [51.8, 247.0], [51.9, 248.0], [52.0, 248.0], [52.1, 249.0], [52.2, 249.0], [52.3, 250.0], [52.4, 251.0], [52.5, 251.0], [52.6, 252.0], [52.7, 253.0], [52.8, 253.0], [52.9, 254.0], [53.0, 255.0], [53.1, 255.0], [53.2, 256.0], [53.3, 257.0], [53.4, 257.0], [53.5, 258.0], [53.6, 259.0], [53.7, 260.0], [53.8, 261.0], [53.9, 261.0], [54.0, 262.0], [54.1, 262.0], [54.2, 263.0], [54.3, 264.0], [54.4, 264.0], [54.5, 265.0], [54.6, 266.0], [54.7, 266.0], [54.8, 267.0], [54.9, 268.0], [55.0, 268.0], [55.1, 269.0], [55.2, 270.0], [55.3, 271.0], [55.4, 272.0], [55.5, 273.0], [55.6, 273.0], [55.7, 274.0], [55.8, 274.0], [55.9, 275.0], [56.0, 276.0], [56.1, 276.0], [56.2, 277.0], [56.3, 278.0], [56.4, 279.0], [56.5, 279.0], [56.6, 280.0], [56.7, 281.0], [56.8, 281.0], [56.9, 282.0], [57.0, 283.0], [57.1, 283.0], [57.2, 284.0], [57.3, 285.0], [57.4, 285.0], [57.5, 286.0], [57.6, 287.0], [57.7, 288.0], [57.8, 288.0], [57.9, 289.0], [58.0, 290.0], [58.1, 291.0], [58.2, 292.0], [58.3, 293.0], [58.4, 294.0], [58.5, 295.0], [58.6, 296.0], [58.7, 297.0], [58.8, 297.0], [58.9, 298.0], [59.0, 299.0], [59.1, 300.0], [59.2, 301.0], [59.3, 302.0], [59.4, 302.0], [59.5, 303.0], [59.6, 304.0], [59.7, 305.0], [59.8, 306.0], [59.9, 307.0], [60.0, 308.0], [60.1, 308.0], [60.2, 309.0], [60.3, 310.0], [60.4, 311.0], [60.5, 312.0], [60.6, 313.0], [60.7, 314.0], [60.8, 315.0], [60.9, 315.0], [61.0, 316.0], [61.1, 317.0], [61.2, 318.0], [61.3, 319.0], [61.4, 320.0], [61.5, 321.0], [61.6, 322.0], [61.7, 323.0], [61.8, 324.0], [61.9, 324.0], [62.0, 325.0], [62.1, 326.0], [62.2, 327.0], [62.3, 328.0], [62.4, 329.0], [62.5, 330.0], [62.6, 331.0], [62.7, 331.0], [62.8, 332.0], [62.9, 333.0], [63.0, 334.0], [63.1, 335.0], [63.2, 335.0], [63.3, 336.0], [63.4, 337.0], [63.5, 338.0], [63.6, 338.0], [63.7, 339.0], [63.8, 340.0], [63.9, 341.0], [64.0, 342.0], [64.1, 343.0], [64.2, 344.0], [64.3, 345.0], [64.4, 346.0], [64.5, 347.0], [64.6, 348.0], [64.7, 349.0], [64.8, 350.0], [64.9, 351.0], [65.0, 352.0], [65.1, 353.0], [65.2, 354.0], [65.3, 355.0], [65.4, 355.0], [65.5, 356.0], [65.6, 357.0], [65.7, 358.0], [65.8, 359.0], [65.9, 360.0], [66.0, 361.0], [66.1, 362.0], [66.2, 363.0], [66.3, 364.0], [66.4, 365.0], [66.5, 366.0], [66.6, 367.0], [66.7, 368.0], [66.8, 369.0], [66.9, 370.0], [67.0, 371.0], [67.1, 372.0], [67.2, 373.0], [67.3, 374.0], [67.4, 376.0], [67.5, 376.0], [67.6, 377.0], [67.7, 378.0], [67.8, 379.0], [67.9, 380.0], [68.0, 382.0], [68.1, 383.0], [68.2, 383.0], [68.3, 385.0], [68.4, 386.0], [68.5, 387.0], [68.6, 387.0], [68.7, 388.0], [68.8, 389.0], [68.9, 390.0], [69.0, 392.0], [69.1, 393.0], [69.2, 394.0], [69.3, 395.0], [69.4, 396.0], [69.5, 397.0], [69.6, 398.0], [69.7, 399.0], [69.8, 400.0], [69.9, 401.0], [70.0, 402.0], [70.1, 403.0], [70.2, 404.0], [70.3, 406.0], [70.4, 407.0], [70.5, 408.0], [70.6, 410.0], [70.7, 411.0], [70.8, 412.0], [70.9, 413.0], [71.0, 415.0], [71.1, 416.0], [71.2, 417.0], [71.3, 418.0], [71.4, 419.0], [71.5, 421.0], [71.6, 421.0], [71.7, 423.0], [71.8, 424.0], [71.9, 425.0], [72.0, 426.0], [72.1, 427.0], [72.2, 429.0], [72.3, 430.0], [72.4, 431.0], [72.5, 432.0], [72.6, 434.0], [72.7, 435.0], [72.8, 436.0], [72.9, 437.0], [73.0, 439.0], [73.1, 440.0], [73.2, 441.0], [73.3, 442.0], [73.4, 444.0], [73.5, 445.0], [73.6, 447.0], [73.7, 448.0], [73.8, 449.0], [73.9, 451.0], [74.0, 452.0], [74.1, 453.0], [74.2, 455.0], [74.3, 456.0], [74.4, 458.0], [74.5, 460.0], [74.6, 461.0], [74.7, 462.0], [74.8, 464.0], [74.9, 465.0], [75.0, 467.0], [75.1, 468.0], [75.2, 470.0], [75.3, 471.0], [75.4, 473.0], [75.5, 474.0], [75.6, 476.0], [75.7, 477.0], [75.8, 479.0], [75.9, 481.0], [76.0, 483.0], [76.1, 485.0], [76.2, 486.0], [76.3, 487.0], [76.4, 488.0], [76.5, 490.0], [76.6, 492.0], [76.7, 494.0], [76.8, 495.0], [76.9, 497.0], [77.0, 499.0], [77.1, 501.0], [77.2, 503.0], [77.3, 506.0], [77.4, 508.0], [77.5, 509.0], [77.6, 512.0], [77.7, 513.0], [77.8, 515.0], [77.9, 517.0], [78.0, 519.0], [78.1, 521.0], [78.2, 522.0], [78.3, 524.0], [78.4, 526.0], [78.5, 528.0], [78.6, 529.0], [78.7, 530.0], [78.8, 532.0], [78.9, 534.0], [79.0, 536.0], [79.1, 538.0], [79.2, 540.0], [79.3, 542.0], [79.4, 544.0], [79.5, 547.0], [79.6, 548.0], [79.7, 550.0], [79.8, 552.0], [79.9, 553.0], [80.0, 555.0], [80.1, 557.0], [80.2, 559.0], [80.3, 560.0], [80.4, 563.0], [80.5, 565.0], [80.6, 567.0], [80.7, 569.0], [80.8, 571.0], [80.9, 573.0], [81.0, 575.0], [81.1, 577.0], [81.2, 579.0], [81.3, 581.0], [81.4, 583.0], [81.5, 585.0], [81.6, 588.0], [81.7, 591.0], [81.8, 593.0], [81.9, 595.0], [82.0, 598.0], [82.1, 600.0], [82.2, 603.0], [82.3, 606.0], [82.4, 608.0], [82.5, 611.0], [82.6, 613.0], [82.7, 616.0], [82.8, 619.0], [82.9, 621.0], [83.0, 623.0], [83.1, 626.0], [83.2, 629.0], [83.3, 632.0], [83.4, 635.0], [83.5, 638.0], [83.6, 640.0], [83.7, 643.0], [83.8, 645.0], [83.9, 647.0], [84.0, 651.0], [84.1, 654.0], [84.2, 656.0], [84.3, 658.0], [84.4, 661.0], [84.5, 664.0], [84.6, 667.0], [84.7, 670.0], [84.8, 672.0], [84.9, 676.0], [85.0, 678.0], [85.1, 681.0], [85.2, 684.0], [85.3, 687.0], [85.4, 690.0], [85.5, 693.0], [85.6, 695.0], [85.7, 699.0], [85.8, 702.0], [85.9, 705.0], [86.0, 708.0], [86.1, 711.0], [86.2, 713.0], [86.3, 715.0], [86.4, 718.0], [86.5, 721.0], [86.6, 723.0], [86.7, 726.0], [86.8, 730.0], [86.9, 733.0], [87.0, 737.0], [87.1, 741.0], [87.2, 744.0], [87.3, 747.0], [87.4, 750.0], [87.5, 754.0], [87.6, 756.0], [87.7, 760.0], [87.8, 763.0], [87.9, 766.0], [88.0, 770.0], [88.1, 773.0], [88.2, 776.0], [88.3, 779.0], [88.4, 783.0], [88.5, 787.0], [88.6, 790.0], [88.7, 793.0], [88.8, 798.0], [88.9, 801.0], [89.0, 805.0], [89.1, 809.0], [89.2, 813.0], [89.3, 817.0], [89.4, 821.0], [89.5, 825.0], [89.6, 830.0], [89.7, 834.0], [89.8, 839.0], [89.9, 843.0], [90.0, 848.0], [90.1, 852.0], [90.2, 857.0], [90.3, 861.0], [90.4, 866.0], [90.5, 871.0], [90.6, 876.0], [90.7, 880.0], [90.8, 885.0], [90.9, 889.0], [91.0, 895.0], [91.1, 900.0], [91.2, 903.0], [91.3, 909.0], [91.4, 915.0], [91.5, 922.0], [91.6, 928.0], [91.7, 933.0], [91.8, 939.0], [91.9, 944.0], [92.0, 950.0], [92.1, 954.0], [92.2, 958.0], [92.3, 964.0], [92.4, 968.0], [92.5, 972.0], [92.6, 977.0], [92.7, 984.0], [92.8, 989.0], [92.9, 994.0], [93.0, 997.0], [93.1, 1002.0], [93.2, 1006.0], [93.3, 1009.0], [93.4, 1013.0], [93.5, 1017.0], [93.6, 1021.0], [93.7, 1027.0], [93.8, 1031.0], [93.9, 1035.0], [94.0, 1040.0], [94.1, 1043.0], [94.2, 1048.0], [94.3, 1054.0], [94.4, 1060.0], [94.5, 1064.0], [94.6, 1068.0], [94.7, 1073.0], [94.8, 1078.0], [94.9, 1082.0], [95.0, 1088.0], [95.1, 1093.0], [95.2, 1098.0], [95.3, 1105.0], [95.4, 1115.0], [95.5, 1121.0], [95.6, 1130.0], [95.7, 1136.0], [95.8, 1144.0], [95.9, 1152.0], [96.0, 1159.0], [96.1, 1166.0], [96.2, 1173.0], [96.3, 1180.0], [96.4, 1189.0], [96.5, 1199.0], [96.6, 1209.0], [96.7, 1221.0], [96.8, 1231.0], [96.9, 1242.0], [97.0, 1255.0], [97.1, 1267.0], [97.2, 1282.0], [97.3, 1302.0], [97.4, 1314.0], [97.5, 1330.0], [97.6, 1353.0], [97.7, 1383.0], [97.8, 1415.0], [97.9, 1458.0], [98.0, 1490.0], [98.1, 1527.0], [98.2, 1561.0], [98.3, 1586.0], [98.4, 1619.0], [98.5, 1645.0], [98.6, 1672.0], [98.7, 1707.0], [98.8, 1739.0], [98.9, 1773.0], [99.0, 1802.0], [99.1, 1824.0], [99.2, 1848.0], [99.3, 1880.0], [99.4, 1905.0], [99.5, 1942.0], [99.6, 1983.0], [99.7, 2021.0], [99.8, 2063.0], [99.9, 2230.0], [100.0, 2887.0]], "isOverall": false, "label": "GET_weatherApi/plot", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "maxY": 9603.0, "series": [{"data": [[0.0, 8336.0], [600.0, 1574.0], [700.0, 1335.0], [800.0, 955.0], [900.0, 835.0], [1000.0, 926.0], [1100.0, 552.0], [1200.0, 333.0], [1300.0, 203.0], [1400.0, 107.0], [1500.0, 141.0], [100.0, 9603.0], [1600.0, 141.0], [1700.0, 134.0], [1800.0, 168.0], [1900.0, 106.0], [2000.0, 93.0], [2100.0, 18.0], [2200.0, 8.0], [2300.0, 2.0], [2400.0, 6.0], [2500.0, 5.0], [2600.0, 8.0], [2700.0, 9.0], [2800.0, 9.0], [200.0, 7290.0], [300.0, 4565.0], [400.0, 3104.0], [500.0, 2146.0]], "isOverall": false, "label": "GET_weatherApi/plot", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 2800.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 847.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 32916.0, "series": [{"data": [[0.0, 32916.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 8949.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 847.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 13.739987677141109, "minX": 1.64644854E12, "maxY": 96.5673377299549, "series": [{"data": [[1.64644872E12, 49.50116121540543], [1.6464486E12, 77.09579165540264], [1.64644878E12, 13.739987677141109], [1.64644866E12, 96.5673377299549], [1.64644854E12, 28.874521306933893]], "isOverall": false, "label": "jp@gc - Stepping Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64644878E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 16.357142857142858, "minX": 1.0, "maxY": 1201.8125, "series": [{"data": [[2.0, 16.357142857142858], [3.0, 17.050000000000004], [4.0, 20.71428571428571], [5.0, 24.3], [6.0, 28.81818181818182], [7.0, 33.85714285714286], [8.0, 42.6875], [9.0, 46.23809523809524], [10.0, 45.34334470989765], [11.0, 44.44827586206896], [12.0, 56.75], [13.0, 53.96296296296296], [14.0, 56.37037037037037], [15.0, 59.68000000000001], [16.0, 62.599999999999994], [17.0, 71.60714285714286], [18.0, 73.00000000000003], [19.0, 76.33333333333333], [20.0, 92.8209718670077], [21.0, 84.19047619047619], [22.0, 97.73333333333335], [23.0, 146.07142857142858], [24.0, 144.0], [25.0, 136.55172413793107], [26.0, 114.64285714285714], [27.0, 130.68000000000006], [28.0, 128.47619047619048], [29.0, 124.13793103448279], [30.0, 143.78645207782805], [31.0, 127.74074074074073], [32.0, 135.73684210526318], [33.0, 134.06060606060606], [34.0, 138.95454545454547], [35.0, 147.2941176470588], [36.0, 130.1428571428571], [37.0, 143.57142857142858], [38.0, 166.99999999999997], [39.0, 177.91304347826085], [40.0, 188.92291118027296], [41.0, 159.8148148148148], [42.0, 226.00000000000003], [43.0, 230.50000000000003], [44.0, 230.02439024390247], [45.0, 216.23333333333335], [46.0, 211.22222222222223], [47.0, 238.78048780487802], [48.0, 197.54545454545456], [49.0, 246.04878048780486], [50.0, 244.5014792899406], [51.0, 214.875], [52.0, 326.0454545454545], [53.0, 248.14285714285714], [54.0, 285.0], [55.0, 261.2272727272727], [56.0, 277.39473684210526], [57.0, 343.5454545454545], [58.0, 298.5769230769231], [59.0, 301.00000000000006], [60.0, 304.2914521112265], [61.0, 271.7096774193548], [62.0, 370.5], [63.0, 335.12820512820514], [64.0, 296.31034482758616], [65.0, 487.47058823529414], [66.0, 342.6666666666667], [67.0, 370.30000000000007], [68.0, 359.9714285714286], [69.0, 284.2], [70.0, 390.46426529445324], [71.0, 859.2500000000001], [72.0, 594.6296296296294], [73.0, 503.2903225806452], [74.0, 497.1621621621623], [75.0, 483.3], [76.0, 849.6875000000001], [77.0, 726.7857142857141], [78.0, 591.4358974358976], [79.0, 482.67441860465107], [80.0, 459.88988898889875], [81.0, 467.41509433962256], [82.0, 411.1875], [83.0, 499.75], [84.0, 527.5], [85.0, 528.1612903225806], [86.0, 586.8636363636363], [87.0, 477.7066666666666], [88.0, 824.4444444444445], [89.0, 667.5], [90.0, 673.8200000000002], [91.0, 697.7], [92.0, 697.3124999999999], [93.0, 802.5217391304348], [94.0, 750.548387096774], [95.0, 1109.8749999999998], [96.0, 868.6470588235294], [97.0, 815.1999999999998], [98.0, 1201.8125], [99.0, 961.75], [100.0, 990.7403223126747], [1.0, 36.0]], "isOverall": false, "label": "GET_weatherApi/plot", "isController": false}, {"data": [[54.37523412624119, 362.7402369357556]], "isOverall": false, "label": "GET_weatherApi/plot-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 0.0, "minX": 1.64644854E12, "maxY": 2.25508193E7, "series": [{"data": [[1.64644872E12, 1.8988036066666666E7], [1.6464486E12, 2.03899977E7], [1.64644878E12, 5964308.6], [1.64644866E12, 1.0587290866666667E7], [1.64644854E12, 2.25508193E7]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.64644872E12, 0.0], [1.6464486E12, 0.0], [1.64644878E12, 0.0], [1.64644866E12, 0.0], [1.64644854E12, 0.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64644878E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 71.69192852741838, "minX": 1.64644854E12, "maxY": 1015.9548767788958, "series": [{"data": [[1.64644872E12, 301.2829494871292], [1.6464486E12, 428.3355861944663], [1.64644878E12, 71.69192852741838], [1.64644866E12, 1015.9548767788958], [1.64644854E12, 125.48024117982557]], "isOverall": false, "label": "GET_weatherApi/plot", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64644878E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 58.93807763401117, "minX": 1.64644854E12, "maxY": 724.1994099271069, "series": [{"data": [[1.64644872E12, 231.8265918327868], [1.6464486E12, 333.06677480400117], [1.64644878E12, 58.93807763401117], [1.64644866E12, 724.1994099271069], [1.64644854E12, 104.61394931964485]], "isOverall": false, "label": "GET_weatherApi/plot", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64644878E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.64644854E12, "maxY": 4.9E-324, "series": [{"data": [[1.64644872E12, 0.0], [1.6464486E12, 0.0], [1.64644878E12, 0.0], [1.64644866E12, 0.0], [1.64644854E12, 0.0]], "isOverall": false, "label": "GET_weatherApi/plot", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64644878E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 11.0, "minX": 1.64644854E12, "maxY": 2887.0, "series": [{"data": [[1.64644872E12, 1255.0], [1.6464486E12, 1662.0], [1.64644878E12, 281.0], [1.64644866E12, 2887.0], [1.64644854E12, 361.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.64644872E12, 554.0], [1.6464486E12, 722.0], [1.64644878E12, 119.0], [1.64644866E12, 1694.6999999999998], [1.64644854E12, 213.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.64644872E12, 954.6499999999996], [1.6464486E12, 1049.0800000000017], [1.64644878E12, 241.0599999999995], [1.64644866E12, 2126.74], [1.64644854E12, 300.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.64644872E12, 683.0], [1.6464486E12, 847.0], [1.64644878E12, 147.0], [1.64644866E12, 1885.8499999999995], [1.64644854E12, 236.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.64644872E12, 43.0], [1.6464486E12, 130.0], [1.64644878E12, 25.0], [1.64644866E12, 233.0], [1.64644854E12, 11.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.64644872E12, 244.0], [1.6464486E12, 370.0], [1.64644878E12, 52.0], [1.64644866E12, 972.0], [1.64644854E12, 122.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64644878E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 16.0, "minX": 19.0, "maxY": 1896.0, "series": [{"data": [[19.0, 1896.0], [32.0, 1510.0], [37.0, 1796.0], [36.0, 1678.5], [41.0, 1208.0], [49.0, 1030.0], [55.0, 16.0], [54.0, 1231.0], [56.0, 1260.0], [59.0, 1090.0], [62.0, 1792.0], [66.0, 1061.0], [70.0, 1171.5], [68.0, 1172.5], [74.0, 1177.5], [79.0, 1549.0], [78.0, 954.0], [77.0, 804.0], [76.0, 873.0], [82.0, 1006.0], [83.0, 971.0], [84.0, 1542.5], [86.0, 1043.0], [88.0, 979.5], [91.0, 1202.0], [90.0, 1849.5], [95.0, 1630.0], [93.0, 1004.0], [96.0, 1113.5], [98.0, 1038.5], [97.0, 877.0], [100.0, 1661.5], [102.0, 963.0], [104.0, 1000.0], [105.0, 789.0], [110.0, 899.0], [109.0, 981.0], [111.0, 508.0], [113.0, 971.0], [115.0, 898.0], [118.0, 914.5], [119.0, 966.0], [117.0, 484.0], [116.0, 46.0], [120.0, 635.0], [123.0, 584.0], [122.0, 714.5], [121.0, 780.0], [124.0, 394.5], [133.0, 736.5], [129.0, 675.5], [131.0, 888.0], [128.0, 576.0], [130.0, 510.0], [138.0, 686.0], [143.0, 559.0], [142.0, 666.0], [137.0, 789.0], [140.0, 565.0], [148.0, 449.0], [144.0, 728.0], [145.0, 572.0], [149.0, 560.0], [158.0, 396.5], [155.0, 370.0], [159.0, 570.0], [156.0, 358.5], [167.0, 275.5], [160.0, 369.5], [162.0, 355.0], [164.0, 248.5], [172.0, 433.0], [171.0, 296.0], [168.0, 371.5], [174.0, 337.5], [173.0, 377.0], [170.0, 315.0], [180.0, 469.5], [177.0, 153.0], [183.0, 551.0], [179.0, 457.0], [178.0, 539.5], [182.0, 89.0], [188.0, 309.5], [190.0, 216.5], [186.0, 342.0], [191.0, 137.0], [187.0, 454.0], [189.0, 69.0], [192.0, 338.0], [196.0, 387.0], [193.0, 369.0], [194.0, 182.0], [198.0, 98.0], [197.0, 47.0], [206.0, 202.0], [202.0, 140.0], [205.0, 261.0], [203.0, 265.0], [201.0, 166.5], [200.0, 152.0], [204.0, 139.0], [208.0, 200.0], [214.0, 235.0], [209.0, 91.0], [210.0, 138.5], [215.0, 150.5], [211.0, 174.0], [212.0, 278.0], [213.0, 126.0], [220.0, 46.0], [221.0, 297.0], [222.0, 167.0], [223.0, 174.5], [217.0, 197.0], [216.0, 223.0], [219.0, 179.0], [218.0, 183.0], [228.0, 137.0], [224.0, 117.0], [231.0, 249.0], [227.0, 223.0], [226.0, 280.0], [239.0, 41.0], [238.0, 41.0], [236.0, 43.0], [233.0, 80.0], [235.0, 157.0], [232.0, 187.0], [234.0, 169.0], [240.0, 101.0], [241.0, 41.0], [245.0, 184.0], [246.0, 80.0], [242.0, 176.5], [247.0, 220.0], [243.0, 203.0], [253.0, 113.5], [251.0, 80.0], [252.0, 76.0], [255.0, 79.0], [249.0, 238.0], [264.0, 75.0], [256.0, 114.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 264.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 12.0, "minX": 19.0, "maxY": 1704.0, "series": [{"data": [[19.0, 1704.0], [32.0, 1375.5], [37.0, 1249.0], [36.0, 1172.0], [41.0, 952.0], [49.0, 673.5], [55.0, 12.0], [54.0, 941.0], [56.0, 1146.5], [59.0, 893.0], [62.0, 1379.5], [66.0, 682.5], [70.0, 913.0], [68.0, 1042.5], [74.0, 856.0], [79.0, 1130.0], [78.0, 752.0], [77.0, 525.0], [76.0, 656.0], [82.0, 786.5], [83.0, 803.0], [84.0, 1088.0], [86.0, 763.5], [88.0, 620.0], [91.0, 1034.0], [90.0, 1037.5], [95.0, 1276.0], [93.0, 786.0], [96.0, 893.5], [98.0, 748.0], [97.0, 726.0], [100.0, 1159.5], [102.0, 777.5], [104.0, 742.5], [105.0, 597.0], [110.0, 618.5], [109.0, 796.0], [111.0, 340.0], [113.0, 722.0], [115.0, 761.0], [118.0, 791.0], [119.0, 683.0], [117.0, 373.0], [116.0, 38.0], [120.0, 416.5], [123.0, 374.0], [122.0, 515.0], [121.0, 499.0], [124.0, 305.5], [133.0, 511.5], [129.0, 474.0], [131.0, 737.0], [128.0, 381.5], [130.0, 302.5], [138.0, 492.5], [143.0, 395.0], [142.0, 483.0], [137.0, 554.5], [140.0, 369.5], [148.0, 334.5], [144.0, 630.0], [145.0, 399.0], [149.0, 385.0], [158.0, 295.5], [155.0, 275.0], [159.0, 312.0], [156.0, 251.0], [167.0, 161.0], [160.0, 252.0], [162.0, 279.0], [164.0, 178.0], [172.0, 304.0], [171.0, 251.5], [168.0, 310.0], [174.0, 255.5], [173.0, 305.0], [170.0, 237.5], [180.0, 333.0], [177.0, 120.0], [183.0, 446.0], [179.0, 386.0], [178.0, 437.0], [182.0, 76.0], [188.0, 253.5], [190.0, 185.0], [186.0, 290.5], [191.0, 118.5], [187.0, 339.0], [189.0, 58.0], [192.0, 273.5], [196.0, 317.5], [193.0, 249.0], [194.0, 149.0], [198.0, 81.5], [197.0, 40.0], [206.0, 159.0], [202.0, 125.5], [205.0, 211.0], [203.0, 230.0], [201.0, 133.0], [200.0, 113.0], [204.0, 116.0], [208.0, 118.0], [214.0, 195.0], [209.0, 74.0], [210.0, 120.0], [215.0, 120.0], [211.0, 149.0], [212.0, 227.5], [213.0, 105.0], [220.0, 38.0], [221.0, 241.0], [222.0, 141.0], [223.0, 146.5], [217.0, 167.0], [216.0, 178.0], [219.0, 146.0], [218.0, 152.5], [228.0, 118.5], [224.0, 96.0], [231.0, 200.0], [227.0, 171.0], [226.0, 231.5], [239.0, 33.0], [238.0, 34.0], [236.0, 35.0], [233.0, 67.0], [235.0, 130.5], [232.0, 158.0], [234.0, 144.0], [240.0, 86.0], [241.0, 33.0], [245.0, 154.0], [246.0, 69.0], [242.0, 143.0], [247.0, 187.0], [243.0, 171.0], [253.0, 96.0], [251.0, 63.0], [252.0, 64.0], [255.0, 67.0], [249.0, 195.0], [264.0, 59.0], [256.0, 97.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 264.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 53.766666666666666, "minX": 1.64644854E12, "maxY": 205.38333333333333, "series": [{"data": [[1.64644872E12, 171.23333333333332], [1.6464486E12, 185.78333333333333], [1.64644878E12, 53.766666666666666], [1.64644866E12, 95.7], [1.64644854E12, 205.38333333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64644878E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 54.1, "minX": 1.64644854E12, "maxY": 204.55, "series": [{"data": [[1.64644872E12, 172.23333333333332], [1.6464486E12, 184.95], [1.64644878E12, 54.1], [1.64644866E12, 96.03333333333333], [1.64644854E12, 204.55]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64644878E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 54.1, "minX": 1.64644854E12, "maxY": 204.55, "series": [{"data": [[1.64644872E12, 172.23333333333332], [1.6464486E12, 184.95], [1.64644878E12, 54.1], [1.64644866E12, 96.03333333333333], [1.64644854E12, 204.55]], "isOverall": false, "label": "GET_weatherApi/plot-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64644878E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 54.1, "minX": 1.64644854E12, "maxY": 204.55, "series": [{"data": [[1.64644872E12, 172.23333333333332], [1.6464486E12, 184.95], [1.64644878E12, 54.1], [1.64644866E12, 96.03333333333333], [1.64644854E12, 204.55]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64644878E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

