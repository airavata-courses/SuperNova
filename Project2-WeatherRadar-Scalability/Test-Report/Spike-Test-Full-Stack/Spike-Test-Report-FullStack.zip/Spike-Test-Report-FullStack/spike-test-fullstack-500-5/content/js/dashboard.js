/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.50619403900404, "KoPercent": 8.493805960995953};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4506929964430271, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9577922077922078, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9090909090909091, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.2140391254315305, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.22957422324510932, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.24913693901035674, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.07019562715765247, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.670995670995671, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.4080717488789238, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.2675489067894131, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.3845291479820628, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.30264672036823936, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.4147982062780269, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9936708860759493, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.4013452914798206, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9936708860759493, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.43946188340807174, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.2807825086306099, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.40919282511210764, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.25891829689298046, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9899103139013453, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9887892376681614, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.4204035874439462, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.4428251121076233, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9938271604938271, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.06767676767676768, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.02586206896551724, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 16306, 1385, 8.493805960995953, 9054.44118729305, 2, 162016, 1355.5, 25914.0, 51825.0, 79379.53, 68.50281892502753, 33811.59651332635, 43.49034860828705], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 462, 0, 0.0, 234.7467532467532, 7, 4617, 164.0, 456.09999999999997, 622.499999999999, 1320.690000000001, 2.6932493878978665, 198.72708715897167, 1.280871535064708], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 462, 0, 0.0, 353.9285714285716, 10, 7356, 216.5, 634.4, 914.8499999999999, 2766.460000000001, 2.6921978707162295, 0.6546457712972081, 1.5669432919403055], "isController": false}, {"data": ["GET_UI_login-7", 869, 87, 10.01150747986191, 12064.185270425776, 11, 104957, 4861.0, 28124.0, 51907.0, 89857.8, 4.409130807596491, 844.2566019234135, 2.324830281443597], "isController": false}, {"data": ["GET_UI_login-6", 869, 73, 8.400460299194476, 11720.019562715772, 20, 144468, 4900.0, 28596.0, 51823.0, 55349.699999999546, 3.652135175231043, 1136.464520258003, 1.96996037391308], "isController": false}, {"data": ["GET_UI_login-9", 869, 330, 37.9746835443038, 21795.784810126595, 6, 140847, 4913.0, 51824.0, 52213.0, 80350.29999999993, 3.6524421766706037, 178.02241872239128, 1.322980872488158], "isController": false}, {"data": ["GET_UI_login-8", 869, 106, 12.197928653624857, 24562.247410817017, 111, 103905, 16569.0, 53401.0, 61461.0, 93360.79999999986, 4.433040177933764, 17518.62129349825, 2.2806451756891875], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 462, 0, 0.0, 983.0606060606054, 26, 10414, 492.5, 2367.7, 3371.249999999999, 9535.2, 2.692401832231896, 66.68609957406727, 1.3199079294730585], "isController": false}, {"data": ["GET_UI_dashboard-9", 446, 34, 7.623318385650224, 3866.885650224215, 5, 26458, 1416.0, 9864.800000000003, 25906.0, 26275.65, 2.674486240787714, 0.9099849485191381, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 869, 72, 8.285385500575375, 10581.99194476409, 6, 140962, 4454.0, 21213.0, 51822.0, 52212.0, 3.70673696243783, 4.808190891621666, 1.998604441792713], "isController": false}, {"data": ["GET_UI_dashboard-8", 446, 20, 4.484304932735426, 3361.834080717488, 29, 26263, 1469.5, 8793.400000000009, 13621.54999999999, 25943.43, 3.157522123893805, 32.758393252212386, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 869, 0, 0.0, 5372.095512082853, 3, 17793, 3085.0, 12441.0, 14283.5, 16246.299999999997, 8.415486819933761, 9.138692718521819, 4.898076313164571], "isController": false}, {"data": ["GET_UI_dashboard-7", 446, 20, 4.484304932735426, 3290.365470852018, 6, 26309, 1496.5, 8158.300000000001, 14162.149999999985, 25964.46, 3.1575891877349607, 0.8948060622526495, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 869, 0, 0.0, 145.5960874568469, 71, 1063, 115.0, 249.0, 347.5, 576.899999999998, 8.413042636409402, 12.003374308392711, 5.118481994612361], "isController": false}, {"data": ["GET_UI_dashboard-6", 446, 20, 4.484304932735426, 3294.1928251121085, 7, 26275, 1527.0, 8259.100000000004, 16040.149999999961, 25936.6, 3.165927240461402, 0.8971689219165927, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 869, 0, 0.0, 146.31185270425783, 71, 1065, 116.0, 234.0, 333.5, 576.0999999999979, 8.413042636409402, 61.38070462560024, 5.299230957503969], "isController": false}, {"data": ["GET_UI_dashboard-5", 446, 20, 4.484304932735426, 3132.4170403587436, 6, 26261, 1216.5, 8243.4, 12157.3, 25947.0, 3.165949713928759, 0.8942221861379673, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 869, 73, 8.400460299194476, 10721.833141541998, 5, 105707, 4655.0, 21079.0, 51822.5, 52228.9, 4.362844032091253, 29.469063626482313, 2.3455111091865732], "isController": false}, {"data": ["GET_UI_dashboard-4", 446, 20, 4.484304932735426, 3231.6681614349777, 9, 26281, 1384.0, 8574.900000000003, 12190.9, 25931.95, 3.166129513154345, 0.8972262424928654, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 869, 73, 8.400460299194476, 10872.582278481015, 9, 108935, 4654.0, 21803.0, 51824.0, 52221.1, 4.293266142977125, 309.1938623956326, 2.3081052998863694], "isController": false}, {"data": ["GET_UI_dashboard-3", 446, 0, 0.0, 139.99103139013454, 73, 1081, 107.0, 189.3, 358.94999999999993, 810.2599999999989, 3.866292173792434, 5.470954452954333, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 446, 0, 0.0, 141.060538116592, 71, 1081, 110.0, 184.60000000000002, 365.14999999999975, 719.4399999999987, 3.866292173792434, 28.1589912423281, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 446, 20, 4.484304932735426, 3272.1322869955156, 9, 26251, 1288.5, 8550.500000000011, 15632.64999999995, 25939.95, 3.165927240461402, 0.8912627551020408, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 446, 0, 0.0, 2325.6255605381166, 5, 25966, 1161.0, 5122.8, 10308.549999999994, 15500.21, 3.8817037720412886, 4.215287689951087, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 405, 1, 0.24691358024691357, 98.66913580246913, 2, 698, 63.0, 208.80000000000007, 274.0, 479.09999999999997, 4.520795660036167, 2.270502907122765, 3.2368949249882797], "isController": false}, {"data": ["GET_UI_dashboard", 495, 83, 16.767676767676768, 11121.599999999997, 122, 77862, 5558.0, 25921.8, 46398.39999999999, 67174.04000000001, 2.71284903954183, 54.07169803969254, 0.0], "isController": false}, {"data": ["GET_UI_login", 870, 333, 38.275862068965516, 41278.67701149425, 196, 162016, 20689.0, 84159.7, 115980.45, 118865.61999999998, 3.6549554053429567, 16768.314174629937, 19.634029210235557], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 105, 7.581227436823105, 0.6439347479455415], "isController": false}, {"data": ["Non HTTP response code: java.io.InterruptedIOException/Non HTTP response message: Connection already shutdown", 1, 0.07220216606498195, 0.006132711885195634], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, 0.9386281588447654, 0.07972525450754324], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,104,548)", 1, 0.07220216606498195, 0.006132711885195634], "isController": false}, {"data": ["Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 203, 14.657039711191336, 1.2449405126947135], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 695, 50.18050541516246, 4.262234760210966], "isController": false}, {"data": ["Assertion failed", 366, 26.425992779783392, 2.244572549981602], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4400 failed to respond", 1, 0.07220216606498195, 0.006132711885195634], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 16306, 1385, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 695, "Assertion failed", 366, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 203, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 105, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 869, 87, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 60, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 27, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-6", 869, 73, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 73, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-9", 869, 330, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 277, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 52, "Non HTTP response code: java.io.InterruptedIOException/Non HTTP response message: Connection already shutdown", 1, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 869, 106, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 66, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 26, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,104,548)", 1, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-9", 446, 34, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 34, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-1", 869, 72, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 72, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-8", 446, 20, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-7", 446, 20, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-6", 446, 20, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-5", 446, 20, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-5", 869, 73, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 73, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-4", 446, 20, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-4", 869, 73, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 73, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-1", 446, 20, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 405, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4400 failed to respond", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard", 495, 83, "Non HTTP response code: java.net.ConnectException/Non HTTP response message: Operation timed out", 49, "Assertion failed", 34, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login", 870, 333, "Assertion failed", 332, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 1, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
