/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.79759460252274, "KoPercent": 0.20240539747726605};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9069521853916105, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9968203497615262, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9944664031620554, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.8757374631268436, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.8772123893805309, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.8912241887905604, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.581858407079646, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.9746031746031746, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.9241245136186771, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.9218289085545722, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.9171206225680933, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.9144542772861357, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.9326848249027238, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9937315634218289, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.9319066147859922, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9944690265486725, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.932295719844358, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.9233038348082596, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.935408560311284, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.9133480825958702, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9937743190661479, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9937743190661479, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.9342412451361868, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.9291828793774319, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9988057324840764, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.8272373540856031, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.5154867256637168, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 34090, 69, 0.20240539747726605, 363.414843062484, 2, 16120, 80.0, 1074.9000000000015, 1931.9000000000015, 9150.88000000002, 192.5814615627966, 80522.74914083509, 106.69168191364058], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1258, 0, 0.0, 73.62957074721771, 6, 1438, 46.0, 151.10000000000014, 254.0999999999999, 428.5100000000009, 7.144804398200736, 527.1944635930188, 3.3979684979724203], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1265, 0, 0.0, 78.35652173913054, 7, 1244, 46.0, 175.4000000000001, 292.5000000000002, 531.0399999999995, 7.179912138308379, 1.7458966039441273, 4.178933236749798], "isController": false}, {"data": ["GET_UI_login-7", 1356, 0, 0.0, 357.33702064896704, 7, 9098, 76.0, 985.1999999999998, 1575.5999999999995, 4671.340000000002, 7.672113339066673, 1630.4964074098696, 4.495378909609379], "isController": false}, {"data": ["GET_UI_login-6", 1356, 0, 0.0, 340.2662241887908, 12, 10773, 84.0, 1136.1999999999998, 1508.2999999999997, 2840.01, 7.669856784090138, 2603.7141456466775, 4.5165269929749545], "isController": false}, {"data": ["GET_UI_login-9", 1356, 2, 0.14749262536873156, 350.54867256637135, 4, 11617, 69.0, 937.2999999999995, 1624.0, 5801.830000000088, 7.6730250165513265, 590.4512287591315, 4.474317682191905], "isController": false}, {"data": ["GET_UI_login-8", 1356, 33, 2.433628318584071, 1961.298672566372, 79, 15728, 579.0, 7720.199999999997, 9088.449999999993, 11179.080000000016, 7.66786170706054, 33669.88932144407, 4.383547531129483], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1260, 0, 0.0, 179.4126984126985, 11, 2661, 128.0, 350.9000000000001, 483.0, 895.3900000000001, 7.1543755252220125, 479.0323853490029, 3.50732081412251], "isController": false}, {"data": ["GET_UI_dashboard-9", 1285, 0, 0.0, 212.00233463034982, 2, 3900, 48.0, 606.6000000000008, 1230.5000000000002, 2131.9800000000005, 7.293387139800326, 1.47434681439323, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1356, 0, 0.0, 224.6209439528024, 3, 10657, 39.0, 636.5999999999999, 1282.099999999998, 2198.5800000000004, 7.670550967303994, 9.0188900045254, 4.5094450022627], "isController": false}, {"data": ["GET_UI_dashboard-8", 1285, 0, 0.0, 283.8303501945523, 11, 6576, 75.0, 766.4000000000001, 1293.5000000000007, 4533.300000000009, 7.2930559891029825, 486.77354325108547, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1356, 0, 0.0, 232.1120943952801, 2, 5217, 38.0, 700.7999999999993, 1315.1499999999999, 2410.1900000000023, 7.665694321959162, 8.324464927752528, 4.4616736483277935], "isController": false}, {"data": ["GET_UI_dashboard-7", 1285, 0, 0.0, 201.7556420233464, 3, 3932, 40.0, 593.2000000000025, 1127.3000000000004, 2140.4400000000046, 7.293221560692657, 1.474313342835332, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1356, 0, 0.0, 98.47787610619476, 60, 1096, 77.0, 118.29999999999995, 203.14999999999986, 575.2900000000002, 7.667731629392971, 10.939996006389777, 4.665035942492013], "isController": false}, {"data": ["GET_UI_dashboard-6", 1285, 0, 0.0, 193.3385214007782, 4, 3145, 39.0, 558.4000000000005, 1177.8000000000002, 1938.7200000000048, 7.293138773958103, 1.474296607626296, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1356, 0, 0.0, 99.01622418879056, 58, 1142, 77.5, 120.29999999999995, 203.14999999999986, 555.0500000000022, 7.667774988125127, 55.943307554963695, 4.8297996751374095], "isController": false}, {"data": ["GET_UI_dashboard-5", 1285, 0, 0.0, 191.54552529182885, 3, 3871, 36.0, 553.6000000000008, 1125.2000000000012, 2048.5000000000027, 7.293180167090447, 1.4671827289263983, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1356, 0, 0.0, 223.49852507374658, 3, 8511, 42.0, 628.3, 1269.4499999999996, 2633.3000000000006, 7.670637749041171, 54.70572996215593, 4.502005163255609], "isController": false}, {"data": ["GET_UI_dashboard-4", 1285, 0, 0.0, 186.31828793774324, 3, 3135, 34.0, 534.4000000000015, 1135.1000000000006, 1983.260000000001, 7.2930559891029825, 1.474279872797185, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1356, 0, 0.0, 251.3296460176988, 4, 10903, 52.0, 756.3, 1331.5499999999977, 2478.0100000000257, 7.670507577171755, 601.2209757411713, 4.501928763554907], "isController": false}, {"data": ["GET_UI_dashboard-3", 1285, 0, 0.0, 97.12451361867699, 57, 1105, 78.0, 113.40000000000009, 183.50000000000068, 567.9800000000007, 7.290242421835552, 10.31597780199191, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 1285, 0, 0.0, 99.01556420233453, 58, 1098, 78.0, 115.40000000000009, 189.4000000000001, 573.2800000000002, 7.290242421835552, 53.09631638872026, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 1285, 0, 0.0, 185.4754863813231, 3, 3121, 34.0, 544.6000000000004, 1124.7, 2003.9000000000035, 7.293180167090447, 1.460060482669474, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 1285, 0, 0.0, 199.3914396887164, 2, 3882, 31.0, 609.6000000000022, 1266.9000000000008, 2155.7000000000007, 7.292724868475565, 7.9194434118601835, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1256, 0, 0.0, 41.89410828025472, 2, 621, 20.0, 90.29999999999995, 206.0, 354.43000000000006, 7.13559331663059, 3.531534592856453, 5.121739343479965], "isController": false}, {"data": ["GET_UI_dashboard", 1285, 0, 0.0, 667.5229571984429, 65, 6872, 188.0, 2427.2000000000007, 3833.600000000002, 5309.42, 7.289663427446576, 566.6906922414722, 0.0], "isController": false}, {"data": ["GET_UI_login", 1356, 34, 2.5073746312684366, 2265.3502949852464, 110, 16120, 684.5, 8936.699999999999, 10451.099999999999, 12813.87, 7.660324490441542, 39193.9350700025, 45.28505721234239], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, 1.4492753623188406, 0.002933411557641537], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 34, 49.27536231884058, 0.09973599295981227], "isController": false}, {"data": ["Assertion failed", 34, 49.27536231884058, 0.09973599295981227], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 34090, 69, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 34, "Assertion failed", 34, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 1356, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 1356, 33, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 32, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 1356, 34, "Assertion failed", 34, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
