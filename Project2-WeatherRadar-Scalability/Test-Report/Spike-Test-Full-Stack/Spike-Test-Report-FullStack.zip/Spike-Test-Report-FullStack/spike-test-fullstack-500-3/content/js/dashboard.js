/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.89684813753581, "KoPercent": 1.1031518624641834};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5874641833810889, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9170673076923077, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9190307328605201, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.35320754716981134, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.3543396226415094, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.4249056603773585, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.04830188679245283, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.6008303677342823, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.6556655665566556, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.5015094339622641, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.6089108910891089, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.5018867924528302, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.6562156215621562, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9830188679245283, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.6600660066006601, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9826415094339622, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.665016501650165, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.4871698113207547, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.665016501650165, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.4615094339622641, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9785478547854786, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.9790979097909791, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.6666666666666666, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.6622662266226622, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9290909090909091, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.2667766776677668, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.036226415094339624, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 27920, 308, 1.1031518624641834, 4097.823925501433, 1, 81780, 822.0, 13159.600000000006, 27681.850000000046, 68508.72000000004, 155.45916691258762, 73501.63438838065, 96.97595628163332], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 832, 0, 0.0, 312.4411057692307, 14, 4522, 189.0, 699.9000000000003, 1176.9499999999985, 2375.399999999999, 4.673185910793824, 344.8208799294529, 2.222501502496672], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 846, 0, 0.0, 324.7647754137116, 7, 3469, 184.0, 598.9000000000009, 1505.449999999999, 2959.159999999998, 4.739071007640772, 1.1523717586938986, 2.758287422415918], "isController": false}, {"data": ["GET_UI_login-7", 1325, 3, 0.22641509433962265, 4757.351698113207, 15, 70299, 1455.0, 13979.600000000002, 18040.400000000005, 38554.9, 7.394427113271462, 1567.9528886050484, 4.322862312976802], "isController": false}, {"data": ["GET_UI_login-6", 1325, 0, 0.0, 4269.166792452827, 20, 38302, 1386.0, 13099.800000000001, 16923.40000000001, 23558.7, 7.394468379578989, 2510.22704353284, 4.354359797740362], "isController": false}, {"data": ["GET_UI_login-9", 1325, 6, 0.4528301886792453, 4450.538113207542, 7, 69228, 1202.0, 12205.400000000005, 16713.8, 34101.28, 7.394096999391731, 567.2823698394783, 4.298483739264608], "isController": false}, {"data": ["GET_UI_login-8", 1325, 146, 11.018867924528301, 22816.22716981137, 15, 79310, 8020.0, 63749.0, 67451.3, 74581.86, 7.387624474502938, 29586.092891667802, 3.851713998572655], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 843, 0, 0.0, 1066.353499406882, 55, 12524, 657.0, 1991.000000000001, 3156.7999999999993, 9624.679999999953, 4.721683899225935, 845.186893205158, 2.314731755284589], "isController": false}, {"data": ["GET_UI_dashboard-9", 909, 0, 0.0, 1455.8921892189223, 7, 19694, 515.0, 3431.0, 8821.0, 15628.099999999993, 5.0904122169893204, 3.1811138846733233, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1325, 0, 0.0, 3019.0573584905674, 6, 21102, 943.0, 10752.6, 13625.9, 15789.4, 7.39508742946761, 8.695005141678713, 4.347502570839357], "isController": false}, {"data": ["GET_UI_dashboard-8", 909, 0, 0.0, 2157.8558855885576, 18, 34098, 585.0, 7296.0, 10839.5, 19177.1, 5.090155672527718, 1210.6614507503639, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1325, 0, 0.0, 2063.46566037736, 4, 30021, 919.0, 6691.200000000006, 8139.300000000024, 12844.36, 7.391745790888907, 8.026973944793422, 4.302227042353309], "isController": false}, {"data": ["GET_UI_dashboard-7", 909, 0, 0.0, 1435.1914191419135, 6, 19740, 497.0, 2830.0, 8061.5, 15382.0, 5.090497737556562, 4.5960859010993005, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1325, 1, 0.07547169811320754, 149.39094339622628, 1, 1284, 93.0, 279.4000000000001, 396.10000000000014, 805.48, 7.392240657881523, 10.549792014776113, 4.494033380848239], "isController": false}, {"data": ["GET_UI_dashboard-6", 909, 0, 0.0, 1426.1496149614973, 6, 19860, 512.0, 2804.0, 8625.5, 15619.999999999987, 5.090269689095959, 1.028990064104359, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1325, 0, 0.0, 150.14264150943384, 60, 1305, 93.0, 293.4000000000001, 407.60000000000036, 802.0, 7.392240657881523, 53.93303706546178, 4.6562453362632645], "isController": false}, {"data": ["GET_UI_dashboard-5", 909, 0, 0.0, 1401.3641364136415, 5, 18837, 481.0, 2989.0, 8482.5, 15461.3, 5.090212680173369, 1.0240076290192521, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1325, 0, 0.0, 3178.778113207546, 6, 25937, 1034.0, 11100.0, 13953.700000000003, 17429.620000000006, 7.394715987096919, 52.73790122438359, 4.34006280102075], "isController": false}, {"data": ["GET_UI_dashboard-4", 909, 0, 0.0, 1405.1045104510436, 6, 19227, 475.0, 2821.0, 8199.5, 15381.4, 5.090269689095959, 1.028990064104359, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1325, 0, 0.0, 3365.2249056603773, 7, 31739, 1060.0, 11512.8, 14247.800000000001, 17122.56, 7.394303317112371, 579.5718484746808, 4.339820599203647], "isController": false}, {"data": ["GET_UI_dashboard-3", 909, 0, 0.0, 136.35423542354224, 60, 2319, 83.0, 262.0, 428.5, 784.8999999999997, 5.087990327780763, 7.199705063431958, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 909, 0, 0.0, 136.5621562156216, 61, 1937, 83.0, 264.0, 431.5, 794.6999999999999, 5.087990327780763, 37.05686705526263, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 909, 0, 0.0, 1446.907590759076, 8, 19745, 481.0, 2848.0, 8768.0, 15411.699999999999, 5.090127169183732, 1.0190195992994777, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 909, 0, 0.0, 1401.7678767876766, 4, 18590, 497.0, 3218.0, 7147.0, 15580.699999999997, 5.089870653452041, 5.527281412733076, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 825, 0, 0.0, 261.4969696969696, 5, 3124, 141.0, 481.5999999999997, 1236.1999999999982, 2349.7800000000007, 4.63459712711155, 2.397246461204209, 3.3265907113544824], "isController": false}, {"data": ["GET_UI_dashboard", 909, 0, 0.0, 4606.935093509351, 80, 36529, 1721.0, 17579.0, 24111.5, 33835.0, 5.087420806375786, 1271.658523799713, 0.0], "isController": false}, {"data": ["GET_UI_login", 1325, 152, 11.471698113207546, 25214.395471698135, 201, 81780, 9075.0, 69206.20000000001, 72755.2, 79372.86, 7.383384320477886, 34920.12575065858, 43.25012180842765], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 11, 3.5714285714285716, 0.03939828080229226], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 144, 46.753246753246756, 0.5157593123209169], "isController": false}, {"data": ["Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, 0.3246753246753247, 0.0035816618911174787], "isController": false}, {"data": ["Assertion failed", 152, 49.35064935064935, 0.5444126074498568], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 27920, 308, "Assertion failed", 152, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 144, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 11, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 1325, 3, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 1325, 6, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 6, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 1325, 146, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 143, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 3, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-3", 1325, 1, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 1325, 152, "Assertion failed", 152, null, null, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
