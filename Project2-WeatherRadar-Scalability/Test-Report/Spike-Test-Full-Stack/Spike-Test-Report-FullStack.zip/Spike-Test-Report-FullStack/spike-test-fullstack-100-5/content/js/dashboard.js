/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.69028741328047, "KoPercent": 0.3097125867195243};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8137078790882062, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.977797513321492, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.9616055846422339, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.7852807283763278, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.7716236722306525, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.795144157814871, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.5204855842185129, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.9063047285464098, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.8338870431893688, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.7776934749620638, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.8272425249169435, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.7723823975720789, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.8388704318936877, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.91350531107739, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.834717607973422, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9119878603945372, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.8546511627906976, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.7898330804248862, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.8438538205980066, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.7792109256449166, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9144518272425249, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.909468438538206, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.834717607973422, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.8596345514950167, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9973166368515206, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.6303986710963455, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.4219219219219219, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 16144, 50, 0.3097125867195243, 887.0395812685821, 2, 51863, 118.0, 2430.0, 4564.0, 12539.899999999987, 10.76230074844122, 4579.618192070012, 6.044420791776413], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 563, 0, 0.0, 132.9573712255773, 6, 2210, 63.0, 332.0000000000001, 464.1999999999998, 956.5200000000004, 3.226545933864405, 238.07749772551435, 1.5344998728437158], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 573, 0, 0.0, 178.11343804537537, 7, 4119, 85.0, 389.0000000000002, 569.9999999999995, 1688.9399999999962, 3.280866194481503, 0.7977887523690373, 1.9095666522568122], "isController": false}, {"data": ["GET_UI_login-7", 659, 3, 0.4552352048558422, 894.6585735963581, 7, 11816, 84.0, 3127.0, 4893.0, 9899.199999999997, 3.7308996620110624, 789.3183325826006, 2.176122242163129], "isController": false}, {"data": ["GET_UI_login-6", 659, 0, 0.0, 941.8922610015184, 11, 13684, 101.0, 3417.0, 5171.0, 9654.99999999999, 3.730498380997668, 1266.405837598428, 2.1967680895914], "isController": false}, {"data": ["GET_UI_login-9", 659, 2, 0.30349013657056145, 883.4248861912006, 3, 12184, 69.0, 3195.0, 5550.0, 8912.999999999995, 3.7318715420727457, 286.73316614119386, 2.1727405436130636], "isController": false}, {"data": ["GET_UI_login-8", 659, 18, 2.731411229135053, 3170.447647951441, 90, 31288, 669.0, 11249.0, 17198.0, 26664.799999999952, 3.729506109259249, 16326.444733743894, 2.1255691175388653], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 571, 0, 0.0, 352.05779334500863, 23, 4221, 245.0, 713.0, 1044.8, 2184.7599999999966, 3.2718875525020485, 100.84136905358791, 1.6039917493711215], "isController": false}, {"data": ["GET_UI_dashboard-9", 602, 0, 0.0, 609.8089700996682, 2, 16563, 45.0, 2124.1000000000004, 3913.300000000003, 7096.120000000016, 3.4420258780882462, 1.1352608160088509, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 659, 0, 0.0, 773.3520485584231, 3, 10667, 45.0, 2907.0, 4089.0, 6994.799999999999, 3.7306884507169826, 4.386473529944578, 2.193236764972289], "isController": false}, {"data": ["GET_UI_dashboard-8", 602, 0, 0.0, 621.4235880398674, 11, 9658, 92.0, 2009.800000000003, 3711.0500000000006, 7660.210000000019, 3.4417503759054604, 206.53262587830383, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 659, 0, 0.0, 760.7177541729892, 2, 9049, 48.0, 2931.0, 3966.0, 6551.199999999979, 3.727987056700477, 4.048360944385674, 2.1698049665951995], "isController": false}, {"data": ["GET_UI_dashboard-7", 602, 0, 0.0, 576.9019933554814, 4, 9173, 40.5, 2173.1000000000013, 3520.750000000001, 6870.82, 3.4416519929566194, 0.6957245727949416, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 659, 0, 0.0, 301.74355083459807, 57, 1796, 218.0, 666.0, 842.0, 1052.1999999999994, 3.7292739516722313, 5.320770745501103, 2.2688844452068357], "isController": false}, {"data": ["GET_UI_dashboard-6", 602, 0, 0.0, 578.2475083056487, 3, 9540, 46.0, 2095.1000000000004, 3362.650000000005, 6997.920000000012, 3.441671669096418, 0.695728550295858, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 659, 0, 0.0, 304.5660091047042, 58, 1796, 217.0, 661.0, 831.0, 1076.3999999999994, 3.7293161599927562, 27.20871194463465, 2.3490321515579375], "isController": false}, {"data": ["GET_UI_dashboard-5", 602, 0, 0.0, 555.2657807308984, 3, 9636, 36.0, 2034.8000000000006, 3410.8500000000004, 7719.890000000001, 3.4417110220509626, 0.6923754595141585, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 659, 0, 0.0, 768.040971168437, 3, 11108, 44.0, 2854.0, 4557.0, 6992.599999999999, 3.730709570770258, 26.60680858919453, 2.1896059101884036], "isController": false}, {"data": ["GET_UI_dashboard-4", 602, 0, 0.0, 577.3205980066443, 3, 9645, 41.5, 2150.2000000000044, 3580.3500000000017, 7677.88, 3.4416519929566194, 0.6957245727949416, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 659, 0, 0.0, 859.4309559939287, 3, 10234, 58.0, 3486.0, 4734.0, 7276.399999999998, 3.730603972895096, 292.4079453833068, 2.189543933310501], "isController": false}, {"data": ["GET_UI_dashboard-3", 602, 0, 0.0, 303.5847176079738, 58, 1577, 220.0, 637.7, 850.2500000000001, 1385.7900000000002, 3.4405701516251264, 4.868541161821102, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 602, 0, 0.0, 313.8006644518275, 61, 1495, 231.5, 703.3000000000004, 881.7, 1403.0, 3.4405504880780926, 25.05822806649064, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 602, 0, 0.0, 574.5365448504982, 3, 9888, 40.5, 2076.4, 3320.900000000005, 7048.460000000001, 3.4417110220509626, 0.6890144135941868, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 602, 0, 0.0, 500.51495016611307, 3, 10048, 38.0, 1462.2000000000016, 2825.2500000000023, 8127.270000000016, 3.4411798330856294, 3.7369062249914258, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 559, 0, 0.0, 42.4096601073345, 2, 712, 24.0, 90.0, 151.0, 346.59999999999786, 3.2067278182204095, 1.5748436522994935, 2.3017040492109384], "isController": false}, {"data": ["GET_UI_dashboard", 602, 0, 0.0, 1961.4933554817258, 66, 20603, 411.0, 6555.300000000001, 9291.6, 14125.64000000001, 3.4399606861635865, 244.68383865791532, 0.0], "isController": false}, {"data": ["GET_UI_login", 666, 27, 4.054054054054054, 4858.608108108109, 105, 51863, 856.0, 15853.2, 21166.89999999999, 51808.32, 0.44400503205702996, 2241.5199527209224, 2.5948699033172375], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 10, 20.0, 0.06194251734390486], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, 26.0, 0.08052527254707631], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 7, 14.0, 0.0433597621407334], "isController": false}, {"data": ["Assertion failed", 20, 40.0, 0.12388503468780972], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 16144, 50, "Assertion failed", 20, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 10, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 7, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-7", 659, 3, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 659, 2, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 659, 18, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 13, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 5, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login", 666, 27, "Assertion failed", 20, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:4200 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Operation timed out", 7, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
