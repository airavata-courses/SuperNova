/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 88.94426975312771, "KoPercent": 11.055730246872281};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.34383153810129125, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5325596389426177, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.4708617482951023, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.15870786516853932, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.19382022471910113, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.14279026217228463, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.019662921348314606, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.1267123287671233, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.24741735537190082, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.21722846441947566, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.21487603305785125, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.24859550561797752, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.22727272727272727, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.9667602996254682, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.2675619834710744, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.9653558052434457, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.26704545454545453, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.20973782771535582, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.265495867768595, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.20833333333333334, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.9963842975206612, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.996900826446281, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.2649793388429752, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.2887396694214876, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.6389618922470434, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.0283775447254781, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.003701418877236274, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 29894, 3305, 11.055730246872281, 2197.2983541847866, 1, 83610, 1632.0, 5988.0, 8196.35000000001, 22086.720000000045, 97.5525388330505, 35091.61917274793, 49.68916605820063], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1551, 712, 45.90586718246293, 673.4074790457777, 3, 76711, 66.0, 324.5999999999997, 1102.399999999993, 7953.96, 6.19235836627141, 252.70030623677488, 1.6481358795464527], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1613, 227, 14.07315561066336, 1398.5151890886568, 1, 83610, 501.0, 3229.800000000003, 4666.899999999999, 11099.99999999992, 6.3654050299722575, 3.1382563789704854, 3.1834732795056055], "isController": false}, {"data": ["GET_UI_login-7", 1068, 19, 1.7790262172284643, 2978.536516853933, 73, 38945, 2160.5, 6071.600000000001, 8265.799999999997, 12566.579999999998, 4.669117807787984, 974.8167510271076, 2.6871404167231363], "isController": false}, {"data": ["GET_UI_login-6", 1068, 5, 0.4681647940074906, 2636.037453183521, 30, 38064, 2014.0, 4786.800000000001, 6948.5, 13271.34, 4.673019873460922, 1578.9869666213258, 2.7389051670670237], "isController": false}, {"data": ["GET_UI_login-9", 1068, 48, 4.49438202247191, 2446.0093632958815, 53, 33697, 1956.5, 3584.1, 5507.2, 11704.31, 4.665303768936416, 343.8097905855218, 2.602016662735231], "isController": false}, {"data": ["GET_UI_login-8", 1068, 98, 9.176029962546817, 6407.641385767797, 429, 41250, 5332.0, 9464.900000000001, 17174.699999999997, 35525.55, 4.645518249318179, 18989.469484085945, 2.4722133415108374], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1606, 860, 53.5491905354919, 3216.5485678704904, 4, 75292, 479.0, 7441.0, 13205.49999999999, 41550.020000000004, 5.3293512526962, 1322.2425647088103, 1.5958849240915878], "isController": false}, {"data": ["GET_UI_dashboard-9", 968, 0, 0.0, 1814.982438016526, 55, 33466, 1711.5, 3150.5, 3657.399999999996, 5144.24, 4.885903059241575, 0.9876776692021542, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 1068, 2, 0.18726591760299627, 2303.600187265917, 11, 33475, 1879.5, 3693.5000000000005, 5487.9, 10553.93, 4.66903615879969, 5.498167141002269, 2.7397423559834047], "isController": false}, {"data": ["GET_UI_dashboard-8", 968, 0, 0.0, 2003.3522727272732, 105, 33320, 1866.5, 3062.6000000000004, 3460.3999999999996, 5770.069999999983, 4.885853737324793, 0.9924390403940987, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 1068, 0, 0.0, 2055.815543071161, 4, 10458, 1629.0, 3469.1, 5443.799999999991, 10329.24, 4.85269260827684, 5.269720879300631, 2.8244187446611293], "isController": false}, {"data": ["GET_UI_dashboard-7", 968, 0, 0.0, 1961.1188016528938, 59, 33324, 1825.0, 3019.1000000000004, 3442.0, 5746.499999999981, 4.891557010894831, 0.9888206066945607, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 1068, 0, 0.0, 182.80524344569287, 67, 1637, 109.0, 264.1, 525.55, 1598.31, 4.8414295816787245, 6.907547479328728, 2.945518192759615], "isController": false}, {"data": ["GET_UI_dashboard-6", 968, 0, 0.0, 1819.5888429752072, 46, 33450, 1694.0, 2800.3, 3174.0, 4460.68999999999, 4.91410469885879, 0.9933785865857125, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 1068, 0, 0.0, 186.32022471910093, 66, 1656, 110.0, 277.1, 524.55, 1606.0, 4.8481987216734455, 35.37196547814679, 3.0537970463665745], "isController": false}, {"data": ["GET_UI_dashboard-5", 968, 0, 0.0, 1824.007231404959, 55, 33459, 1685.5, 2847.6000000000004, 3176.75, 4502.049999999997, 4.914603683921935, 0.9886800379764831, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 1068, 3, 0.2808988764044944, 2381.399812734078, 25, 33475, 1908.5, 4230.3, 5587.75, 10640.31, 4.6768055841409, 33.28858881195782, 2.7371726195037684], "isController": false}, {"data": ["GET_UI_dashboard-4", 968, 0, 0.0, 1823.2241735537218, 30, 33450, 1680.0, 2846.7000000000003, 3174.0, 4532.439999999999, 4.9120349931749105, 0.9929601988156312, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 1068, 3, 0.2808988764044944, 2426.9297752809, 28, 33806, 1907.5, 4229.3, 5985.75, 11881.31, 4.679879585120787, 365.81069882970144, 2.7389717260013757], "isController": false}, {"data": ["GET_UI_dashboard-3", 968, 0, 0.0, 123.85227272727288, 67, 1227, 102.5, 170.0, 242.0, 420.5499999999997, 4.908000344776883, 6.945012206622758, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 968, 0, 0.0, 126.13946280991745, 67, 949, 104.0, 172.10000000000002, 259.54999999999995, 426.4099999999994, 4.908000344776883, 35.74596344858008, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 968, 0, 0.0, 1822.375, 15, 33452, 1685.0, 2805.0, 3175.1, 4566.299999999998, 4.913855244322162, 0.9837307862168391, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 968, 0, 0.0, 1729.7386363636376, 16, 5366, 1778.5, 2967.6000000000004, 3403.55, 4720.549999999999, 4.9120349931749105, 5.334163000400879, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1522, 24, 1.5768725361366622, 1541.5854139290411, 2, 28194, 88.5, 3852.0, 10518.8, 12678.65, 6.076406216938082, 16.67441958243671, 4.292707950730007], "isController": false}, {"data": ["GET_UI_dashboard", 1621, 653, 40.28377544725478, 3238.4398519432402, 4, 39222, 1876.0, 7264.799999999999, 8005.299999999999, 10557.05999999999, 6.406279022894247, 50.32795252990717, 0.0], "isController": false}, {"data": ["GET_UI_login", 1621, 651, 40.16039481801357, 5811.180135718696, 4, 42433, 6136.0, 10861.4, 19155.3, 22743.34, 6.312280715417774, 19984.9202604838, 24.242700786552625], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,322,316)", 7, 0.2118003025718608, 0.02341607011440423], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4300 failed to respond", 1307, 39.54614220877458, 4.372114805646618], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,234,556)", 4, 0.12102874432677761, 0.013380611493945274], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,476,372)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["404/Not Found", 264, 7.987897125567322, 0.8831203586003881], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,299,716)", 4, 0.12102874432677761, 0.013380611493945274], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,165,052)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,670,716)", 4, 0.12102874432677761, 0.013380611493945274], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4400 failed to respond", 24, 0.7261724659606656, 0.08028366896367164], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,387,476)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,983,172)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 654, 19.78819969742814, 2.187729979260052], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 4,141,004)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,485,940)", 2, 0.060514372163388806, 0.006690305746972637], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,257,156)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4700 failed to respond", 227, 6.868381240544629, 0.7593497022813943], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,734,428)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Assertion failed", 98, 2.9652042360060515, 0.3278249816016592], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,104,236)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,702,572)", 28, 0.8472012102874432, 0.09366428045761692], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,290,460)", 5, 0.15128593040847202, 0.016725764367431593], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,411,212)", 7, 0.2118003025718608, 0.02341607011440423], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,355,620)", 2, 0.060514372163388806, 0.006690305746972637], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,392,644)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,169,396)", 2, 0.060514372163388806, 0.006690305746972637], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,619,724)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 653, 19.757942511346446, 2.184384826386566], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,082,516)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,390,940)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 575,613; received: 476,118)", 1, 0.030257186081694403, 0.0033451528734863185], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 29894, 3305, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4300 failed to respond", 1307, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 654, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 653, "404/Not Found", 264, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4700 failed to respond", 227], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 1551, 712, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4300 failed to respond", 683, "404/Not Found", 29, null, null, null, null, null, null], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 1613, 227, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4700 failed to respond", 227, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-7", 1068, 19, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 19, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-6", 1068, 5, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-9", 1068, 48, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 48, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 1068, 98, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 1,702,572)", 28, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 21, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,322,316)", 7, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 3,411,212)", 7, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 4,608,258; received: 2,290,460)", 5], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 1606, 860, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4300 failed to respond", 624, "404/Not Found", 235, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of Content-Length delimited message body (expected: 575,613; received: 476,118)", 1, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-1", 1068, 2, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-5", 1068, 3, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-4", 1068, 3, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 1522, 24, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4400 failed to respond", 24, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard", 1621, 653, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 653, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login", 1621, 651, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 553, "Assertion failed", 98, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
