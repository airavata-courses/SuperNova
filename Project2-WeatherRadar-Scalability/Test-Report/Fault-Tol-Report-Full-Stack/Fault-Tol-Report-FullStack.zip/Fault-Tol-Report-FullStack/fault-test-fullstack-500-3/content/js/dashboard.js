/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 89.92968357609242, "KoPercent": 10.070316423907585};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.02021597187343044, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login"], "isController": false}, {"data": [0.11842105263157894, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [1.0, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [1.0, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.0, 500, 1500, "GET_UI_dashboard-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3982, 401, 10.070316423907585, 103218.64013058785, 15, 456038, 16657.0, 409454.4, 428024.7, 446414.38, 8.688195879325278, 5543.737342612361, 8.277548837010144], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_UI_login-7", 342, 26, 7.60233918128655, 105212.54678362577, 3677, 412902, 20528.5, 369188.5, 373190.1, 405785.47, 0.7590149672425119, 149.13985022423677, 0.4109250439429718], "isController": false}, {"data": ["GET_UI_login-6", 342, 0, 0.0, 22372.318713450288, 3250, 367706, 15913.5, 43619.5, 48814.34999999999, 110306.98, 0.8626800087781474, 292.8571165346371, 0.508003950481663], "isController": false}, {"data": ["GET_UI_login-9", 342, 45, 13.157894736842104, 154224.46783625722, 3460, 417222, 19125.5, 372391.8, 391652.64999999985, 414487.72, 0.7551135761472427, 50.69753607971858, 0.3829515653703148], "isController": false}, {"data": ["GET_UI_login-8", 342, 114, 33.333333333333336, 374552.8859649123, 19620, 448331, 400674.5, 433430.9, 440814.1, 446084.4, 0.7513015970650908, 2254.612330795814, 0.29347718635355113], "isController": false}, {"data": ["GET_UI_dashboard", 20, 11, 55.0, 363672.55000000005, 67837, 405910, 373231.0, 401108.7, 405670.7, 405910.0, 0.04767296347059174, 11.55951345643883, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-9", 20, 0, 0.0, 21143.4, 5264, 40716, 18868.0, 40436.100000000006, 40714.1, 40716.0, 0.367728175332794, 1.4875215178440098, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 342, 0, 0.0, 19249.08187134502, 2705, 213651, 13872.5, 37856.0, 52595.04999999993, 94250.81, 1.3859396022110195, 1.629561797912175, 0.8147808989560875], "isController": false}, {"data": ["GET_UI_dashboard-8", 20, 3, 15.0, 45092.49999999999, 45, 371975, 18700.5, 125219.2, 359638.34999999986, 371975.0, 0.05121271714192068, 11.555729518754097, 0.0], "isController": false}, {"data": ["GET_UI_login", 342, 153, 44.73684210526316, 397241.6754385968, 23865, 456038, 425519.0, 446626.1, 451114.85, 455977.45, 0.7462002696793957, 2761.2937196037938, 4.138783448781642], "isController": false}, {"data": ["GET_UI_login-0", 342, 0, 0.0, 9163.83333333334, 95, 21688, 5070.0, 17237.8, 21604.7, 21650.27, 10.255180065369277, 11.13648460223695, 5.968835272421963], "isController": false}, {"data": ["GET_UI_dashboard-7", 20, 2, 10.0, 44868.149999999994, 23, 371933, 17315.0, 123769.20000000003, 359586.4999999998, 371933.0, 0.051217045032586846, 0.024793251193997362, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 342, 14, 4.093567251461988, 12901.716374269, 1588, 28903, 13395.0, 19951.3, 21068.85, 23068.399999999994, 6.455144297012136, 9.955146066514411, 3.766533049583813], "isController": false}, {"data": ["GET_UI_dashboard-6", 20, 4, 20.0, 41896.799999999996, 15, 346880, 17316.5, 123875.50000000003, 335792.44999999984, 346880.0, 0.05121494657000699, 0.039519033234659204, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 342, 21, 6.140350877192983, 13485.222222222212, 1690, 22928, 14430.5, 19309.899999999998, 20603.5, 22328.56, 6.659397149310694, 47.35109228352091, 3.93707420384181], "isController": false}, {"data": ["GET_UI_dashboard-5", 20, 4, 20.0, 39596.8, 32, 346799, 15973.5, 112689.1, 335093.5499999998, 346799.0, 0.051213241695772856, 0.039765281711239255, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 342, 0, 0.0, 19180.309941520456, 2847, 213980, 13559.0, 37869.6, 53141.39999999999, 94377.02, 1.3841894801599508, 9.871812278914181, 0.8124002710704399], "isController": false}, {"data": ["GET_UI_dashboard-4", 20, 3, 15.0, 45667.05, 51, 372041, 18388.0, 123886.70000000003, 359695.3999999998, 372041.0, 0.05124394680878321, 0.03231771567296113, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 342, 0, 0.0, 18233.795321637423, 2708, 109872, 14149.5, 37675.6, 52550.84999999988, 75378.37999999998, 2.3978125219098367, 187.94260608742903, 1.4073098883474726], "isController": false}, {"data": ["GET_UI_dashboard-3", 20, 0, 0.0, 148.35, 91, 319, 131.0, 258.20000000000005, 316.04999999999995, 319.0, 0.053570328466468996, 0.07580410737100934, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 20, 0, 0.0, 154.85000000000002, 99, 314, 137.0, 259.20000000000005, 311.29999999999995, 314.0, 0.0535696110310543, 0.39015835846640917, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 20, 1, 5.0, 47293.30000000001, 15, 346724, 23356.0, 123875.30000000003, 335643.9999999999, 346724.0, 0.05122753992546392, 0.017481898268509148, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 20, 0, 0.0, 307812.20000000007, 28852, 373029, 337615.0, 372938.9, 373026.3, 373029.0, 0.04974493285677688, 0.054019888024156144, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 105, 26.184538653366584, 2.6368658965344047], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 80, 19.950124688279303, 2.0090406830738323], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 17, 4.239401496259352, 0.42692114515318935], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 32, 7.980049875311721, 0.8036162732295329], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: readHandshakeRecord", 3, 0.7481296758104738, 0.07533902561526871], "isController": false}, {"data": ["Assertion failed", 164, 40.89775561097257, 4.118533400301356], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3982, 401, "Assertion failed", 164, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 105, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 80, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 32, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 17], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET_UI_login-7", 342, 26, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 25, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_login-9", 342, 45, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 45, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 342, 114, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 79, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 35, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard", 20, 11, "Assertion failed", 11, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-8", 20, 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login", 342, 153, "Assertion failed", 153, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-7", 20, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-3", 342, 14, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 13, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: readHandshakeRecord", 1, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-6", 20, 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-2", 342, 21, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 19, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: readHandshakeRecord", 2, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-5", 20, 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-4", 20, 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-1", 20, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
