/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.2766634176371, "KoPercent": 0.7233365823628995};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7582773303237059, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9859700694815606, 500, 1500, "GET_GATEWAY_WeatherApi_plot"], "isController": false}, {"data": [0.6904603068712475, 500, 1500, "POST_GATEWAY_UserApi_userQuery"], "isController": false}, {"data": [0.8820321851310015, 500, 1500, "GET_UI_login-7"], "isController": false}, {"data": [0.8803697300172896, 500, 1500, "GET_UI_login-6"], "isController": false}, {"data": [0.8869530522675888, 500, 1500, "GET_UI_login-9"], "isController": false}, {"data": [0.6037371990956244, 500, 1500, "GET_UI_login-8"], "isController": false}, {"data": [0.19458160950220205, 500, 1500, "GET_GATEWAY_UserApi_sessionInfo"], "isController": false}, {"data": [0.8707692307692307, 500, 1500, "GET_UI_dashboard-9"], "isController": false}, {"data": [0.8983242452453783, 500, 1500, "GET_UI_login-1"], "isController": false}, {"data": [0.8601337792642141, 500, 1500, "GET_UI_dashboard-8"], "isController": false}, {"data": [0.8870860486766857, 500, 1500, "GET_UI_login-0"], "isController": false}, {"data": [0.8721739130434782, 500, 1500, "GET_UI_dashboard-7"], "isController": false}, {"data": [0.5452187790929645, 500, 1500, "GET_UI_login-3"], "isController": false}, {"data": [0.8816053511705686, 500, 1500, "GET_UI_dashboard-6"], "isController": false}, {"data": [0.539433435297247, 500, 1500, "GET_UI_login-2"], "isController": false}, {"data": [0.8812040133779264, 500, 1500, "GET_UI_dashboard-5"], "isController": false}, {"data": [0.8946668439952121, 500, 1500, "GET_UI_login-5"], "isController": false}, {"data": [0.8839464882943144, 500, 1500, "GET_UI_dashboard-4"], "isController": false}, {"data": [0.8899454714722702, 500, 1500, "GET_UI_login-4"], "isController": false}, {"data": [0.6569899665551839, 500, 1500, "GET_UI_dashboard-3"], "isController": false}, {"data": [0.6482274247491638, 500, 1500, "GET_UI_dashboard-2"], "isController": false}, {"data": [0.8789966555183947, 500, 1500, "GET_UI_dashboard-1"], "isController": false}, {"data": [0.8932441471571906, 500, 1500, "GET_UI_dashboard-0"], "isController": false}, {"data": [0.9963254943880278, 500, 1500, "POST_GATEWAY_WeatherApi_queryStatus"], "isController": false}, {"data": [0.391904507868765, 500, 1500, "GET_UI_dashboard"], "isController": false}, {"data": [0.22545116772823778, 500, 1500, "GET_UI_login"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 194930, 1410, 0.7233365823628995, 998.4335658954483, 1, 79223, 54.0, 1116.9000000000015, 2811.5000000000073, 11370.94000000001, 64.76243253982493, 27349.28621322488, 35.09977406198628], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET_GATEWAY_WeatherApi_plot", 7484, 0, 0.0, 106.67156600748267, 8, 2064, 56.0, 254.0, 390.0, 721.0, 2.490536526926181, 288.12151229419544, 1.1844641490361818], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 7495, 442, 5.897264843228819, 1035.6429619746468, 1, 47685, 363.0, 1794.400000000006, 4556.7999999999965, 14757.839999999997, 2.494303370521028, 0.8665618389846471, 1.3665356235275872], "isController": false}, {"data": ["GET_UI_login-7", 7519, 17, 0.22609389546482245, 419.7161856629865, 5, 67822, 83.0, 910.0, 1261.0, 2143.000000000002, 2.4984781181299325, 529.7942688759457, 1.4606421161867091], "isController": false}, {"data": ["GET_UI_login-6", 7519, 16, 0.21279425455512702, 393.9832424524536, 5, 65438, 94.0, 903.0, 1227.0, 2102.800000000002, 2.4984623441285474, 846.368608258512, 1.468131731605698], "isController": false}, {"data": ["GET_UI_login-9", 7519, 24, 0.3191913818326905, 413.7515627078066, 4, 65535, 88.0, 877.0, 1284.0, 2218.000000000001, 2.4985511792603305, 191.94689127794547, 1.4544574799773637], "isController": false}, {"data": ["GET_UI_login-8", 7519, 15, 0.19949461364543158, 1152.4579066365218, 5, 71043, 604.0, 2294.0, 2991.0, 5842.200000000017, 2.4984117026282004, 11221.734709657661, 1.460992679211779], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 7493, 412, 5.498465234218604, 5198.454691044996, 5, 56264, 3084.0, 12911.200000000006, 17556.49999999999, 28677.37999999999, 2.4932950892768013, 880.6041990361274, 1.2222989597821818], "isController": false}, {"data": ["GET_UI_dashboard-9", 7475, 18, 0.2408026755852843, 357.48187290969906, 3, 65853, 96.0, 1019.0, 1449.3999999999996, 2242.6799999999985, 2.486988641032884, 1.2612509593413124, 0.0], "isController": false}, {"data": ["GET_UI_login-1", 7519, 14, 0.18619497273573613, 323.5319856363877, 4, 65382, 45.0, 812.0, 1152.0, 2001.8000000000056, 2.498468985789065, 2.942123291170492, 1.466091612509358], "isController": false}, {"data": ["GET_UI_dashboard-8", 7475, 16, 0.2140468227424749, 373.1309698996661, 4, 65565, 124.0, 1048.0, 1455.5999999999995, 2232.959999999999, 2.4867313338793604, 28.965754819435027, 0.0], "isController": false}, {"data": ["GET_UI_login-0", 7519, 0, 0.0, 454.97207075409045, 3, 65817, 32.0, 873.0, 1251.0, 2155.4000000000005, 2.4981942165757296, 2.7128827820627066, 1.4540271026163427], "isController": false}, {"data": ["GET_UI_dashboard-7", 7475, 13, 0.17391304347826086, 322.39197324414687, 3, 65406, 79.0, 991.2000000000016, 1382.0, 2156.959999999999, 2.4867280248093953, 2.210076933044307, 0.0], "isController": false}, {"data": ["GET_UI_login-3", 7519, 14, 0.18619497273573613, 2005.7038169969408, 2, 59097, 688.0, 5459.0, 7996.0, 15997.800000000014, 2.498405891439795, 3.5767032040668294, 1.5171960281485182], "isController": false}, {"data": ["GET_UI_dashboard-6", 7475, 27, 0.3612040133779264, 297.025685618729, 4, 61556, 73.0, 903.0, 1275.0, 2001.4399999999987, 2.486601459493678, 2.6723363986725706, 0.0], "isController": false}, {"data": ["GET_UI_login-2", 7519, 15, 0.19949461364543158, 2110.8610187524914, 63, 58551, 717.0, 5766.0, 8389.0, 17530.200000000004, 2.4983926088249513, 18.211497023730413, 1.570555127287106], "isController": false}, {"data": ["GET_UI_dashboard-5", 7475, 23, 0.3076923076923077, 287.5340468227431, 3, 6384, 67.0, 919.0, 1292.0, 2008.199999999999, 2.4866022866761366, 0.5679607662602166, 0.0], "isController": false}, {"data": ["GET_UI_login-5", 7519, 21, 0.27929245910360423, 361.6918473201219, 3, 65834, 45.0, 814.0, 1157.0, 1991.6000000000013, 2.4984598535149565, 17.78374979419024, 1.46228573044313], "isController": false}, {"data": ["GET_UI_dashboard-4", 7475, 18, 0.2408026755852843, 289.3446153846148, 3, 39004, 69.0, 912.0, 1277.1999999999998, 1993.4399999999987, 2.4866022866761366, 1.1697094885499866, 0.0], "isController": false}, {"data": ["GET_UI_login-4", 7519, 24, 0.3191913818326905, 381.3641441681071, 4, 65837, 59.0, 843.0, 1143.0, 2021.6000000000013, 2.4984648347471032, 195.223782655698, 1.4617035743556626], "isController": false}, {"data": ["GET_UI_dashboard-3", 7475, 10, 0.13377926421404682, 1444.6325083612055, 62, 39219, 297.0, 4166.600000000002, 6285.799999999999, 13424.399999999987, 2.486507991420466, 3.5242427330556536, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-2", 7475, 8, 0.10702341137123746, 1579.6589966555193, 62, 38984, 312.0, 4517.800000000004, 6939.0, 15566.719999999978, 2.486504682944873, 18.09871807689736, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-1", 7475, 25, 0.33444816053511706, 304.7723076923077, 4, 61556, 70.0, 929.4000000000005, 1294.3999999999996, 2009.4799999999996, 2.4866022866761366, 0.5277597646959027, 0.0], "isController": false}, {"data": ["GET_UI_dashboard-0", 7475, 0, 0.0, 282.78247491638905, 3, 72808, 58.0, 852.4000000000005, 1182.0, 1974.9599999999937, 2.486078790239139, 2.6997261862753152, 0.0], "isController": false}, {"data": ["POST_GATEWAY_WeatherApi_queryStatus", 7484, 0, 0.0, 50.02725815072164, 3, 2208, 23.0, 105.0, 176.0, 451.2999999999993, 2.4905638777720167, 1.3333842009263406, 1.7876605958617504], "isController": false}, {"data": ["GET_UI_dashboard", 7498, 125, 1.667111229661243, 2374.6307015204093, 4, 79223, 1335.5, 5329.300000000005, 8149.749999999989, 18320.92000000002, 2.4936245954262044, 61.70378601536133, 0.0], "isController": false}, {"data": ["GET_UI_login", 7536, 113, 1.4994692144373674, 3615.045382165595, 3, 75416, 2152.0, 7064.4000000000015, 10155.449999999999, 28540.200000000004, 2.5037177018423056, 13028.476898679584, 14.773960096770717], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, 0.07092198581560284, 5.130046683424819E-4], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: fonts.googleapis.com:443 failed to respond", 1, 0.07092198581560284, 5.130046683424819E-4], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 147, 10.425531914893616, 0.07541168624634484], "isController": false}, {"data": ["500", 2, 0.14184397163120568, 0.0010260093366849638], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 163, 11.560283687943262, 0.08361976093982455], "isController": false}, {"data": ["Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, 0.07092198581560284, 5.130046683424819E-4], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 44, 3.120567375886525, 0.022572205407069203], "isController": false}, {"data": ["404/Not Found", 412, 29.21985815602837, 0.21135792335710255], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4700 failed to respond", 440, 31.20567375886525, 0.22572205407069204], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 1, 0.07092198581560284, 5.130046683424819E-4], "isController": false}, {"data": ["Assertion failed", 198, 14.042553191489361, 0.10157492433181142], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 194930, 1410, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4700 failed to respond", 440, "404/Not Found", 412, "Assertion failed", 198, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 163, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 147], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["POST_GATEWAY_UserApi_userQuery", 7495, 442, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4700 failed to respond", 440, "500", 2, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-7", 7519, 17, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 17, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-6", 7519, 16, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 16, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-9", 7519, 24, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 23, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-8", 7519, 15, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 15, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_GATEWAY_UserApi_sessionInfo", 7493, 412, "404/Not Found", 412, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-9", 7475, 18, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 18, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-1", 7519, 14, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 14, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-8", 7475, 16, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 16, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard-7", 7475, 13, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 13, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-3", 7519, 14, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 13, "Non HTTP response code: java.lang.NullPointerException/Non HTTP response message: Cannot read the array length because &quot;addresses&quot; is null", 1, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-6", 7475, 27, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 27, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-2", 7519, 15, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 13, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: fonts.googleapis.com:443 failed to respond", 1, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host terminated the handshake", 1, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-5", 7475, 23, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 23, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-5", 7519, 21, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 21, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-4", 7475, 18, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 18, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login-4", 7519, 24, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 24, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-3", 7475, 10, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 10, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-2", 7475, 8, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Connection reset", 8, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_dashboard-1", 7475, 25, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 25, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET_UI_dashboard", 7498, 125, "Assertion failed", 102, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Unexpected end of file from server", 23, null, null, null, null, null, null], "isController": false}, {"data": ["GET_UI_login", 7536, 113, "Assertion failed", 96, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:4200 failed to respond", 17, null, null, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
