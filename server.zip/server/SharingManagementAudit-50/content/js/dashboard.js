/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 92.02127659574468, "KoPercent": 7.9787234042553195};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8335106382978723, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.76, 500, 1500, "AUDIT_FETCH_LOGS"], "isController": false}, {"data": [1.0, 500, 1500, "Local_Authentication_Logout"], "isController": false}, {"data": [0.0, 500, 1500, "CHECK_USER_PERMISSION_ENTITY"], "isController": false}, {"data": [0.94, 500, 1500, "Update_Permission"], "isController": false}, {"data": [0.9959349593495935, 500, 1500, "GET_ENTITY_TYPE"], "isController": false}, {"data": [0.94, 500, 1500, "Update_Entity"], "isController": false}, {"data": [1.0, 500, 1500, "GET_ENTITY_TYPES"], "isController": false}, {"data": [1.0, 500, 1500, "GET_PERMISSION_TYPES"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 940, 75, 7.9787234042553195, 7031.444680851064, 61, 60120, 210.0, 50705.99999999999, 60010.0, 60095.59, 5.354935370487469, 4.374189327229277, 2.736944096112545], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["AUDIT_FETCH_LOGS", 75, 0, 0.0, 526.4266666666667, 321, 997, 495.0, 740.4, 909.4, 997.0, 0.6250989740042174, 0.4242615106766905, 0.26249273322442723], "isController": false}, {"data": ["Local_Authentication_Logout", 123, 0, 0.0, 99.32520325203251, 61, 282, 92.0, 133.20000000000005, 170.39999999999998, 265.68000000000035, 0.9766633052509547, 0.6592585869944974, 1.0501038076965834], "isController": false}, {"data": ["CHECK_USER_PERMISSION_ENTITY", 123, 75, 60.97560975609756, 52108.731707317085, 7524, 60120, 60008.0, 60087.0, 60103.6, 60118.8, 0.704301968037288, 0.3514128626725683, 0.3095077007976363], "isController": false}, {"data": ["Update_Permission", 125, 0, 0.0, 295.90399999999994, 102, 1215, 216.0, 588.2000000000004, 678.4, 1212.92, 0.9621231363674848, 0.6548826426251337, 0.4801219948083836], "isController": false}, {"data": ["GET_ENTITY_TYPE", 123, 0, 0.0, 202.58536585365857, 99, 521, 185.0, 287.0, 329.8, 503.48000000000036, 0.9763377017169256, 0.792266666203634, 0.3804284599463411], "isController": false}, {"data": ["Update_Entity", 125, 0, 0.0, 323.39200000000005, 127, 1057, 252.0, 591.0000000000002, 781.5999999999988, 1013.8399999999991, 0.968549268164173, 0.6592491128088703, 0.4804912385033202], "isController": false}, {"data": ["GET_ENTITY_TYPES", 123, 0, 0.0, 188.87804878048786, 85, 410, 178.0, 274.0, 301.4, 394.1600000000003, 0.9760355499127122, 1.2857814607800349, 0.35648173405015077], "isController": false}, {"data": ["GET_PERMISSION_TYPES", 123, 0, 0.0, 186.36585365853662, 89, 402, 175.0, 260.0, 301.2, 400.32000000000005, 0.9759348741996144, 1.1150275994184062, 0.36025720942134204], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 8, 10.666666666666666, 0.851063829787234], "isController": false}, {"data": ["504/Gateway Time-out", 67, 89.33333333333333, 7.127659574468085], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 940, 75, "504/Gateway Time-out", 67, "503/Service Unavailable", 8, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["CHECK_USER_PERMISSION_ENTITY", 123, 75, "504/Gateway Time-out", 67, "503/Service Unavailable", 8, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
