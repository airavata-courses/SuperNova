/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.13320079522863, "KoPercent": 8.866799204771372};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.551093439363817, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5249266862170088, 500, 1500, "Get_SSH_Credentials"], "isController": false}, {"data": [0.42660550458715596, 500, 1500, "Save_Password_Credentials"], "isController": false}, {"data": [0.5416666666666666, 500, 1500, "Update_KV_Credentials"], "isController": false}, {"data": [0.923728813559322, 500, 1500, "Get_JWKS"], "isController": false}, {"data": [0.512779552715655, 500, 1500, "Get_Password_Credentials"], "isController": false}, {"data": [0.5532646048109966, 500, 1500, "Get_All_Resource_credential_Summaries"], "isController": false}, {"data": [0.5588235294117647, 500, 1500, "Get_KV_Credentials"], "isController": false}, {"data": [0.35127478753541075, 500, 1500, "Generate_SSH_Credentials"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2515, 223, 8.866799204771372, 6846.422664015906, 85, 60077, 717.0, 30371.4, 49475.2, 60034.0, 10.042245310291406, 13.816396829156051, 4.550528883683647], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get_SSH_Credentials", 341, 8, 2.346041055718475, 5913.202346041053, 99, 30736, 820.0, 30034.6, 30562.0, 30697.22, 1.3742186901801798, 4.516211454626603, 0.5716964472819889], "isController": false}, {"data": ["Save_Password_Credentials", 327, 73, 22.32415902140673, 14559.715596330272, 216, 60068, 909.0, 60011.0, 60037.2, 60047.44, 1.3215698795229416, 0.8763775509430836, 0.7472548439880695], "isController": false}, {"data": ["Update_KV_Credentials", 264, 36, 13.636363636363637, 6663.238636363639, 127, 60077, 688.5, 32473.5, 60008.75, 60059.9, 1.0716851843582675, 0.7064013907550915, 0.5735190244417291], "isController": false}, {"data": ["Get_JWKS", 354, 0, 0.0, 315.8389830508473, 85, 2470, 203.0, 627.5, 926.25, 1471.9999999999993, 1.41643059490085, 3.0593831774859557, 0.47859861898017], "isController": false}, {"data": ["Get_Password_Credentials", 313, 15, 4.792332268370607, 6299.8722044728465, 118, 30777, 776.0, 30301.0, 30444.5, 30696.74, 1.266314418183142, 1.4302377196833, 0.5329897599970062], "isController": false}, {"data": ["Get_All_Resource_credential_Summaries", 291, 9, 3.0927835051546393, 4751.058419243987, 115, 30958, 702.0, 30158.4, 30355.399999999998, 30625.519999999997, 1.1779707328921003, 1.218095044730504, 0.5107607474649342], "isController": false}, {"data": ["Get_KV_Credentials", 272, 15, 5.514705882352941, 3675.176470588235, 93, 33158, 665.0, 4206.900000000013, 30158.699999999997, 30758.399999999994, 1.1049499319562082, 1.1708673552292161, 0.43701633051002375], "isController": false}, {"data": ["Generate_SSH_Credentials", 353, 67, 18.980169971671387, 11944.351274787536, 366, 60043, 1091.0, 57906.6, 60010.0, 60016.38, 1.4172551822156556, 0.969269833793707, 0.7487647007604196], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["503/Service Unavailable", 8, 3.587443946188341, 0.31809145129224653], "isController": false}, {"data": ["504/Gateway Time-out", 83, 37.219730941704036, 3.3001988071570576], "isController": false}, {"data": ["500/Internal Server Error", 132, 59.19282511210762, 5.248508946322068], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2515, 223, "500/Internal Server Error", 132, "504/Gateway Time-out", 83, "503/Service Unavailable", 8, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Get_SSH_Credentials", 341, 8, "500/Internal Server Error", 8, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Save_Password_Credentials", 327, 73, "504/Gateway Time-out", 40, "500/Internal Server Error", 26, "503/Service Unavailable", 7, null, null, null, null], "isController": false}, {"data": ["Update_KV_Credentials", 264, 36, "500/Internal Server Error", 20, "504/Gateway Time-out", 16, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Get_Password_Credentials", 313, 15, "500/Internal Server Error", 15, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Get_All_Resource_credential_Summaries", 291, 9, "500/Internal Server Error", 9, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Get_KV_Credentials", 272, 15, "500/Internal Server Error", 15, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Generate_SSH_Credentials", 353, 67, "500/Internal Server Error", 39, "504/Gateway Time-out", 27, "503/Service Unavailable", 1, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
