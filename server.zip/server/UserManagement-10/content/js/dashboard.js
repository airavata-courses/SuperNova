/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 66.93877551020408, "KoPercent": 33.06122448979592};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.2642857142857143, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.006756756756756757, 500, 1500, "Add_User_Attribute"], "isController": false}, {"data": [0.15873015873015872, 500, 1500, "Enable_User"], "isController": false}, {"data": [0.047619047619047616, 500, 1500, "Diable_User"], "isController": false}, {"data": [0.7545454545454545, 500, 1500, "Get_User_Status"], "isController": false}, {"data": [0.0, 500, 1500, "Delete_User_Attribute"], "isController": false}, {"data": [0.2358490566037736, 500, 1500, "Get_User"], "isController": false}, {"data": [0.33636363636363636, 500, 1500, "Change_User_Password"], "isController": false}, {"data": [0.8055555555555556, 500, 1500, "Check_User_Status"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 490, 162, 33.06122448979592, 3224.2734693877537, 226, 13552, 1721.0, 10612.300000000001, 11103.75, 12157.699999999999, 5.086575592741768, 4.112669109174521, 3.9715657018176724], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add_User_Attribute", 74, 30, 40.54054054054054, 3011.527027027027, 1422, 6470, 2811.5, 4946.5, 5543.5, 6470.0, 0.8777340228685296, 0.701320789545476, 1.5608922418394457], "isController": false}, {"data": ["Enable_User", 63, 26, 41.26984126984127, 1687.142857142857, 599, 5197, 1464.0, 2902.6000000000004, 3993.199999999999, 5197.0, 0.7334450963956413, 0.7905294811458042, 0.2628655765402347], "isController": false}, {"data": ["Diable_User", 63, 51, 80.95238095238095, 7261.825396825398, 696, 12579, 10436.0, 11387.0, 11992.599999999999, 12579.0, 0.6652657367026051, 0.48992605848530607, 0.23972954769849736], "isController": false}, {"data": ["Get_User_Status", 55, 0, 0.0, 575.2727272727273, 229, 2664, 434.0, 1128.3999999999999, 1462.5999999999983, 2664.0, 0.6909374136328232, 0.46698388938092006, 0.2354855052322806], "isController": false}, {"data": ["Delete_User_Attribute", 73, 55, 75.34246575342466, 7756.315068493151, 1532, 13552, 10442.0, 11594.2, 12024.0, 13552.0, 0.7929266597149809, 0.5037680988225582, 1.410077585293926], "isController": false}, {"data": ["Get_User", 53, 0, 0.0, 1731.9056603773586, 757, 3721, 1522.0, 2704.8, 3547.0999999999995, 3721.0, 0.6586960304242997, 0.8135148424100818, 0.22514024477393055], "isController": false}, {"data": ["Change_User_Password", 55, 0, 0.0, 1294.0727272727272, 551, 3629, 1066.0, 1927.6, 2590.5999999999954, 3629.0, 0.6880074054615278, 0.4652845536082861, 0.2613621882075531], "isController": false}, {"data": ["Check_User_Status", 54, 0, 0.0, 600.7407407407408, 226, 3261, 395.5, 1412.5, 1725.5, 3261.0, 0.6761748538084922, 0.4576922128761222, 0.22715248995129037], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 162, 100.0, 33.06122448979592], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 490, 162, "500/Internal Server Error", 162, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Add_User_Attribute", 74, 30, "500/Internal Server Error", 30, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Enable_User", 63, 26, "500/Internal Server Error", 26, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Diable_User", 63, 51, "500/Internal Server Error", 51, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Delete_User_Attribute", 73, 55, "500/Internal Server Error", 55, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
