/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 88.69125090383226, "KoPercent": 11.308749096167752};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5861894432393348, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.7075718015665796, 500, 1500, "Add_Child_Group"], "isController": false}, {"data": [0.37610619469026546, 500, 1500, "Create_Groups"], "isController": false}, {"data": [0.7230263157894737, 500, 1500, "Get_All_Users_of_Group"], "isController": false}, {"data": [0.7377577319587629, 500, 1500, "Find_Group"], "isController": false}, {"data": [0.7166230366492147, 500, 1500, "Get_All_Child_Groups"], "isController": false}, {"data": [0.0, 500, 1500, "Update_Group"], "isController": false}, {"data": [0.6934023285899095, 500, 1500, "Add_User_to_group"], "isController": false}, {"data": [0.6783819628647215, 500, 1500, "Get_All_Groups_of_User"], "isController": false}, {"data": [0.6635514018691588, 500, 1500, "Change_Group_Membership"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 6915, 782, 11.308749096167752, 798.3543022415029, 59, 8376, 618.0, 1597.4000000000005, 2081.0, 3659.6800000000003, 43.24199257100692, 43.959388669456715, 20.942549344882252], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Add_Child_Group", 766, 0, 0.0, 640.526109660574, 61, 3065, 525.0, 1266.3000000000006, 1586.4999999999998, 2459.220000000001, 4.854553520501932, 3.3048585639932826, 2.3988321107167754], "isController": false}, {"data": ["Create_Groups", 791, 0, 0.0, 1584.1694058154242, 180, 8376, 1272.0, 3292.0000000000014, 4000.0, 5371.600000000006, 4.9497825474797414, 4.764198701151403, 3.1612869004411626], "isController": false}, {"data": ["Get_All_Users_of_Group", 760, 0, 0.0, 634.7421052631582, 66, 3233, 501.0, 1283.2999999999997, 1525.1499999999987, 2322.24, 4.831532104259376, 10.68751117490464, 1.9014721074380163], "isController": false}, {"data": ["Find_Group", 776, 0, 0.0, 594.46262886598, 67, 2686, 491.5, 1200.3000000000002, 1434.4999999999993, 1913.5800000000008, 4.917897725472302, 4.178780940848971, 1.9882906819780597], "isController": false}, {"data": ["Get_All_Child_Groups", 764, 0, 0.0, 601.7958115183247, 59, 3209, 523.0, 1175.5, 1468.25, 2048.400000000003, 4.857795044286051, 3.2974236081527026, 1.9307837724847876], "isController": false}, {"data": ["Update_Group", 782, 782, 100.0, 953.6943734015346, 98, 4521, 851.0, 1845.9000000000003, 2146.3999999999996, 2932.5299999999997, 4.9504950495049505, 2.0807561869318327, 3.5388304455445545], "isController": false}, {"data": ["Add_User_to_group", 773, 0, 0.0, 685.3790426908154, 72, 4023, 545.0, 1385.0, 1696.2999999999995, 2581.2, 4.898605830164765, 3.3351094641159693, 2.358410814717997], "isController": false}, {"data": ["Get_All_Groups_of_User", 754, 0, 0.0, 743.9137931034483, 74, 5401, 565.5, 1480.0, 1914.25, 3932.5000000000005, 4.793327484710938, 9.681125170452379, 1.6945161615872653], "isController": false}, {"data": ["Change_Group_Membership", 749, 0, 0.0, 716.8518024032047, 142, 2830, 628.0, 1317.0, 1603.0, 2326.5, 4.757639854920568, 3.239291141833565, 2.2301436819940164], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["404/Not Found", 782, 100.0, 11.308749096167752], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 6915, 782, "404/Not Found", 782, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Update_Group", 782, 782, "404/Not Found", 782, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
